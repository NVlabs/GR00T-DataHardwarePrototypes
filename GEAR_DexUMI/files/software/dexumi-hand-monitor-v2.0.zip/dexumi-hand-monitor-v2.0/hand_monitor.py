#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""
DexUMI Hand Monitor

Live dashboard for the 15 joint encoders and 10 tactile sensors streamed by the
palm board over its second USB CDC interface (UMI protocol). Opens in the web
browser by default; --tui shows the terminal dashboard instead.

Usage:
    ./run.sh                                # auto-detect the board, open the browser view
    ./run.sh --tui                          # terminal view instead
    ./run.sh -p /dev/cu.usbmodem1103        # pick the port explicitly
    ./run.sh --list                         # show candidate serial ports
    ./run.sh --csv run1.csv                 # record from the start
"""

import argparse
import os
import sys

APP_DIR = os.path.dirname(os.path.abspath(__file__))
REQUIRED_FILES = (
    "umi_core.py",
    "web.py",
    "recording_library.py",
    "tui.py",
    "web/index.html",
    "web/app.js",
    "web/style.css",
    "vendor/serial/__init__.py",
)


def check_files():
    """Catch a partly copied folder up front, instead of a confusing import error."""
    missing = [f for f in REQUIRED_FILES if not os.path.isfile(os.path.join(APP_DIR, f))]
    if missing:
        print("Error: this copy of the DexUMI Hand Monitor is incomplete. Missing:", file=sys.stderr)
        for name in missing:
            print(f"  {name}", file=sys.stderr)
        print("Extract the whole zip again (recordings/ can be kept).", file=sys.stderr)
        sys.exit(1)


check_files()

from umi_core import MonitorState, Reader, autodetect_port, list_ports, open_csv  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="Live DexUMI encoder + tactile dashboard")
    parser.add_argument("-p", "--port", help="serial port (default: auto-detect)")
    parser.add_argument("-b", "--baudrate", type=int, default=115200, help="ignored by USB CDC")
    parser.add_argument("--list", action="store_true", help="list candidate ports and exit")
    parser.add_argument("--csv", help="append samples to this CSV file from the start")
    parser.add_argument("--tui", action="store_true", help="use the terminal dashboard instead of the browser")
    parser.add_argument("--http-port", type=int, default=8765, help="local web port for the browser view")
    parser.add_argument("--no-browser", action="store_true", help="do not open the browser automatically")
    parser.add_argument("--vmin", type=float, default=0.0, help="encoder scale minimum (deg)")
    parser.add_argument("--vmax", type=float, default=360.0, help="encoder scale maximum (deg)")
    parser.add_argument("--refresh", type=float, default=20.0, help="terminal view: screen updates per second")
    parser.add_argument(
        "--glitch-rate",
        type=float,
        default=2000.0,
        help="encoder speed (deg/s) above which a frame-to-frame jump counts as a glitch",
    )
    args = parser.parse_args()

    if args.list:
        for port in list_ports.comports():
            vid = f"{port.vid:04X}" if port.vid else "----"
            pid = f"{port.pid:04X}" if port.pid else "----"
            print(f"{port.device:<28} {vid}:{pid}  {port.description}")
        return 0

    if args.tui and not sys.stdout.isatty():
        print("Error: the terminal view needs a terminal (stdout is not a TTY).", file=sys.stderr)
        return 1

    port = args.port
    if not port:
        # A board that is already plugged in is used straight away; otherwise the
        # dashboard starts anyway and the reader keeps looking for it.
        port, _ = autodetect_port(args.baudrate, any_port=False)
        if port:
            print(f"Using {port}", file=sys.stderr)
        else:
            print("No board found yet - starting anyway; it is picked up as soon as you plug it in.",
                  file=sys.stderr)

    if args.tui:
        import tui

        state = MonitorState(glitch_rate=args.glitch_rate)
    else:
        import web

        state = web.WebState(glitch_rate=args.glitch_rate)

    reader = Reader(port, args.baudrate, state, open_csv(args.csv) if args.csv else None)
    reader.start()
    try:
        if args.tui:
            tui.run_dashboard(state, port, args)
        else:
            web.serve(state, reader, port, args)
    except KeyboardInterrupt:
        pass
    finally:
        reader.stop()
        reader.join(timeout=1.0)
        csv_file = reader.set_csv(None)
        if csv_file:
            csv_file.close()

    if state.reconnects:
        print(f"link dropped and recovered {state.reconnects} time(s)", file=sys.stderr)
    if state.frames:
        print(
            f"since last reset: {state.dropped} dropped frame(s) in {state.gaps} gap(s), "
            f"{state.board_resets} board reset(s), {sum(state.glitches)} encoder glitch(es)",
            file=sys.stderr,
        )
        for idx, count in enumerate(state.glitches):
            if count:
                print(f"  encoder #{idx:02d}: {count} glitch(es)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
