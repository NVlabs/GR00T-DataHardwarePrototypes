@echo off
REM SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
REM SPDX-License-Identifier: Apache-2.0

REM Launch the DexUMI Hand Monitor on Windows.
REM
REM pyserial is bundled in vendor\, so the only requirement is Python 3. The
REM terminal view (--tui) also needs the windows-curses package.
setlocal
cd /d "%~dp0"

set "PYTHON="
where py >nul 2>nul && set "PYTHON=py -3"
if not defined PYTHON where python >nul 2>nul && set "PYTHON=python"

if not defined PYTHON (
    echo Error: Python 3 was not found on this computer.
    echo Install it from https://www.python.org/downloads/
    echo and tick "Add python.exe to PATH" during setup.
    exit /b 1
)

%PYTHON% hand_monitor.py %*
set "CODE=%errorlevel%"

if not "%CODE%"=="0" (
    echo.
    echo The monitor exited with code %CODE%.
    echo If --tui reported a missing 'curses' module, run:  %PYTHON% -m pip install windows-curses
)

exit /b %CODE%
