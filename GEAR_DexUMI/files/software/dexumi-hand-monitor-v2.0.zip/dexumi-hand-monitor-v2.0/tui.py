# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""
Terminal (curses) front end of the DexUMI Hand Monitor, started with --tui.

Keys:
    1 / 2 / 3 / 4   encoders | tactile | both (default) | single-sensor raw
    ← / →           pick the sensor shown in the raw view
    z / Z           tare to current values / clear tare
    r               reset min / max / counters
    a               toggle bar autoscale (observed range vs. fixed scale)
    space           freeze the display (capture keeps running)
    q / Esc         quit
"""

import locale
import math
import sys
import time

try:
    import curses
except ImportError:  # curses ships with Python everywhere except Windows
    sys.exit(
        "The terminal view needs the 'curses' module, which Python does not bundle on Windows.\n"
        "Install it once with:  pip install windows-curses   (or drop --tui to use the browser view)"
    )

from umi_core import (
    ENCODER_TO_TACTILE,
    FINGERS,
    JOINTS,
    RAW_CHANNELS,
    SOURCE_NAMES,
)

# ncurses only tracks column widths correctly once the locale is initialised;
# without this, multi-byte glyphs corrupt the screen diff on redraw.
locale.setlocale(locale.LC_ALL, "")
UNICODE_OK = locale.getpreferredencoding(False).lower().replace("-", "") == "utf8"
DEG = "\u00b0" if UNICODE_OK else " "
DELTA = "\u0394" if UNICODE_OK else "d"

# --------------------------------------------------------------------- UI ----

VIEW_ENCODERS, VIEW_TACTILE, VIEW_BOTH, VIEW_RAW = 1, 2, 3, 4
VIEW_NAMES = {VIEW_ENCODERS: "encoders", VIEW_TACTILE: "tactile", VIEW_BOTH: "both", VIEW_RAW: "raw"}

# "<normal:10> <tangential:9> <direction:5>°" - one force group in the tactile table.
# Direction gets 5 digits: a disconnected sensor reports 0xFFFF rather than 0-359.
GROUP_WIDTH = 27
# Columns needed before the tactile table starts losing its right-hand fields.
FULL_WIDTH = 125


def fmt_count(value, width=9):
    """Tactile values are raw counts and can be large; keep the column fixed."""
    if value is None:
        return "-".rjust(width)
    text = f"{value:,}"
    return text.rjust(width) if len(text) <= width else f"{value:.2e}".rjust(width)


def fmt_deg(value):
    """Keep the angle column fixed even if an encoder reports a wild float."""
    text = f"{value:9.2f}" if abs(value) < 1e6 else f"{value:9.2e}"
    return text[:9] + DEG


class Dashboard:
    def __init__(self, state, port, args):
        self.state = state
        self.port = port
        self.args = args
        self.tare = [None] * state.count
        self.tactile_tare = {}
        self.autoscale = False
        self.frozen = False
        self.view = VIEW_BOTH
        self.selected = 0
        self._held = None
        self._repaint = True
        self._size = None

    def run(self, stdscr):
        curses.curs_set(0)
        stdscr.nodelay(True)
        self._init_colors()
        while True:
            key = stdscr.getch()
            if key != -1:
                # Keys reshape the layout; some terminals mis-apply the scroll
                # optimisation ncurses uses for that, so force a full rewrite.
                self._repaint = True
            if not self._handle_key(key):
                return
            snap = self.state.snapshot()
            if self.frozen and self._held is not None:
                snap = self._held
            else:
                self._held = snap
            self._draw(stdscr, snap)
            time.sleep(1.0 / self.args.refresh)

    def _handle_key(self, key):
        if key in (ord("q"), ord("Q"), 27):
            return False
        if key in (ord("1"), ord("2"), ord("3"), ord("4")):
            self.view = key - ord("0")
        elif key == ord("z"):
            self._set_tare()
        elif key == ord("Z"):
            self.tare = [None] * self.state.count
            self.tactile_tare = {}
        elif key == ord("r"):
            self.state.reset_stats()
        elif key == ord("a"):
            self.autoscale = not self.autoscale
        elif key == ord(" "):
            self.frozen = not self.frozen
        elif key in (curses.KEY_RIGHT, ord("]")):
            self.selected += 1
        elif key in (curses.KEY_LEFT, ord("[")):
            self.selected -= 1
        return True

    @staticmethod
    def _init_colors():
        if not curses.has_colors():
            return
        curses.start_color()
        curses.use_default_colors()
        for idx, fg in enumerate(
            (curses.COLOR_GREEN, curses.COLOR_YELLOW, curses.COLOR_RED, curses.COLOR_CYAN), start=1
        ):
            curses.init_pair(idx, fg, -1)

    @staticmethod
    def _color(pair, bold=False):
        if not curses.has_colors():
            return curses.A_BOLD if bold else curses.A_NORMAL
        attr = curses.color_pair(pair)
        return attr | curses.A_BOLD if bold else attr

    def _set_tare(self):
        snap = self.state.snapshot()
        self.tare = [row["value"] for row in snap["encoders"]]
        self.tactile_tare = {
            row["id"]: (row["sample"]["n1"], row["sample"]["n2"])
            for row in snap["tactiles"]
            if row["sample"]
        }

    def _bar(self, value, lo, hi, width):
        if width < 4 or value is None or hi is None or lo is None or hi <= lo:
            return " " * max(0, width)
        frac = min(1.0, max(0.0, (value - lo) / (hi - lo)))
        filled = int(round(frac * (width - 2)))
        return "[" + "#" * filled + "." * (width - 2 - filled) + "]"

    # -- sections ------------------------------------------------------------

    def _draw_encoders(self, stdscr, y, snap, width, limit):
        bar_width = max(10, min(36, width - 68))
        header = (
            f" ID  Finger  Joint  {'Angle':>10}  {DELTA + 'tare':>9}  "
            f"{'position'.center(bar_width)}  {'Min':>8} {'Max':>8} {'Range':>8}  Good  Glit  Tac"
        )
        self._put(stdscr, y, 0, header, self._color(4))
        self._put(stdscr, y + 1, 0, "-" * min(width - 1, len(header)), self._color(4))
        y += 2

        for idx, row in enumerate(snap["encoders"]):
            if y >= limit:
                break
            value = row["value"]
            if value is None:
                angle, attr = "     --   ", self._color(3)
            else:
                angle = fmt_deg(value)
                attr = self._color(2) if row["stale"] else self._color(1)

            tare = self.tare[idx]
            delta = f"{value - tare:+9.2f}" if (tare is not None and value is not None) else " " * 9

            lo, hi = row["min"], row["max"]
            if self.autoscale and lo is not None and hi - lo > 1e-6:
                bar_lo, bar_hi = lo, hi
            else:
                bar_lo, bar_hi = self.args.vmin, self.args.vmax
            min_s = f"{lo:8.2f}" if lo is not None else "      --"
            max_s = f"{hi:8.2f}" if hi is not None else "      --"
            rng_s = f"{hi - lo:8.2f}" if lo is not None else "      --"
            good = f"{row['good'] * 100:3.0f}%" if row["good"] is not None else "  --"
            tactile = ENCODER_TO_TACTILE[idx] if idx < len(ENCODER_TO_TACTILE) else -1
            tac_s = f"{tactile:3d}" if tactile >= 0 else "  -"

            finger = FINGERS[idx // 3] if idx // 3 < len(FINGERS) else "?"
            label = f" #{idx:02d}  {finger:<6} {JOINTS[idx % 3]:<5}  "
            self._put(stdscr, y, 0, label, self._color(4) if idx % 3 == 0 else curses.A_NORMAL)
            col = len(label)
            self._put(stdscr, y, col, angle, attr | curses.A_BOLD)
            col += len(angle)
            self._put(stdscr, y, col, "  " + delta)
            col += 2 + len(delta)
            self._put(stdscr, y, col, "  " + self._bar(value, bar_lo, bar_hi, bar_width), attr)
            col += 2 + bar_width
            stats = f"  {min_s} {max_s} {rng_s}  {good}  "
            self._put(stdscr, y, col, stats)
            col += len(stats)
            glitches = row["glitches"]
            self._put(stdscr, y, col, fmt_count(glitches, 4), self._color(3, bold=True) if glitches else curses.A_NORMAL)
            self._put(stdscr, y, col + 4, f"  {tac_s}")
            y += 1
        return y

    def _draw_tactile(self, stdscr, y, snap, width, limit):
        tared = bool(self.tactile_tare)
        n_label = (DELTA + "Normal") if tared else "Normal"
        bar_width = max(8, min(20, width - 96))
        header = (
            f" Tac  Location     {n_label + '-1':>10} {'Tang-1':>9} {'Dir1':>6}  "
            f"{n_label + '-2':>10} {'Tang-2':>9} {'Dir2':>6}  "
            f"{'Prox-1':>10} {'Prox-2':>10}  {'contact'.center(bar_width)}   Hz"
        )
        self._put(stdscr, y, 0, header, self._color(4))
        self._put(stdscr, y + 1, 0, "-" * min(width - 1, len(header)), self._color(4))
        y += 2

        for row in snap["tactiles"]:
            if y >= limit:
                break
            sample = row["sample"]
            label = f" {row['id']:3d}  {row['location']:<12}"
            if sample is None:
                self._put(stdscr, y, 0, label, curses.A_NORMAL)
                self._put(stdscr, y, len(label), "   no data", self._color(3))
                y += 1
                continue

            attr = self._color(2) if row["stale"] else self._color(1)
            tare = self.tactile_tare.get(row["id"])
            groups = []
            for gi, (n_key, t_key, a_key) in enumerate((("n1", "t1", "a1"), ("n2", "t2", "a2"))):
                n, t, a = sample[n_key], sample[t_key], sample[a_key]
                if n == 0 and t == 0 and a == 0:
                    # Firmware sends all-zero for a group that isn't populated.
                    groups.append(" " * GROUP_WIDTH)
                    continue
                shown = n - tare[gi] if tare else n
                n_str = f"{shown:+,}".rjust(10) if tare else fmt_count(n, 10)
                groups.append(f"{n_str} {fmt_count(t, 9)} {a:5d}{DEG}".rjust(GROUP_WIDTH))

            contact = sample["n1"] if sample["n1"] else sample["n2"]
            peak = max(row["n1_max"], row["n2_max"], 1)
            bar = self._bar(contact, 0, peak, bar_width)

            self._put(stdscr, y, 0, label)
            col = len(label)
            self._put(stdscr, y, col, " " + groups[0] + "  " + groups[1], attr)
            col += 3 + len(groups[0]) + len(groups[1])
            self._put(
                stdscr,
                y,
                col,
                f"  {fmt_count(sample['p1'], 10)} {fmt_count(sample['p2'], 10)}  {bar} {row['hz']:4.0f}",
            )
            y += 1
        return y

    def _draw_raw(self, stdscr, y, snap, width, limit):
        rows = snap["tactiles"]
        if not rows:
            self._put(stdscr, y, 1, "No tactile sensors seen yet.", self._color(3))
            return y + 1
        self.selected %= len(rows)
        row = rows[self.selected]
        sample = row["sample"]

        title = (
            f" Sensor {row['id']} - {row['location']}   "
            f"({self.selected + 1}/{len(rows)}, left/right to change)   {row['hz']:.0f} Hz"
        )
        self._put(stdscr, y, 0, title, self._color(4, bold=True))
        y += 1
        if sample is None:
            self._put(stdscr, y, 1, "No data received from this sensor.", self._color(3))
            return y + 1

        bar_width = max(12, min(48, width - 56))
        self._put(
            stdscr,
            y,
            0,
            f" Ch  {'Value':>12}  {'observed range'.center(bar_width)}  {'Min':>12} {'Max':>12}",
            self._color(4),
        )
        y += 1
        for ch in range(RAW_CHANNELS):
            if y >= limit:
                break
            value = sample["raw"][ch]
            lo = row["raw_min"][ch] if row["raw_min"][ch] != math.inf else None
            hi = row["raw_max"][ch] if row["raw_max"][ch] != -math.inf else None
            bar = self._bar(value, lo, hi, bar_width) if lo is not None and hi > lo else " " * bar_width
            self._put(
                stdscr,
                y,
                0,
                f" {ch:2d}  {fmt_count(value, 12)}  {bar}  {fmt_count(lo, 12)} {fmt_count(hi, 12)}",
                self._color(2) if row["stale"] else curses.A_NORMAL,
            )
            y += 1

        if y < limit:
            self._put(
                stdscr,
                y,
                1,
                f"G1  normal={fmt_count(sample['n1'])} tangential={fmt_count(sample['t1'])} dir={sample['a1']}{DEG}"
                f"    G2  normal={fmt_count(sample['n2'])} tangential={fmt_count(sample['t2'])} dir={sample['a2']}{DEG}"
                f"    prox={fmt_count(sample['p1'])},{fmt_count(sample['p2'])}",
                self._color(1),
            )
            y += 1
        return y

    # -- frame ---------------------------------------------------------------

    def _draw(self, stdscr, snap):
        stdscr.erase()
        height, width = stdscr.getmaxyx()
        if self._size != (height, width):
            self._size = (height, width)
            self._repaint = True

        source = snap["source"]
        if source is None:
            source_str = "--"
        else:
            name = SOURCE_NAMES.get((source >> 4) & 0xF, f"0x{source >> 4:X}")
            source_str = f"{name} #{source & 0xF}"
        version_str = f"0x{snap['version']:02X}" if snap["version"] is not None else "--"

        live = snap["link_age"] is not None and snap["link_age"] < 0.5
        seen = sum(1 for row in snap["tactiles"] if not row["stale"])
        port = snap["port"] or "no board yet"
        title = f" DexUMI Hand Monitor   {port}   src={source_str}   proto={version_str} "
        self._put(stdscr, 0, 0, title.ljust(width - 1), self._color(4, bold=True))

        if snap["port"] is None:
            status = "WAITING FOR BOARD"
        elif live:
            status = "LIVE"
        elif snap["error"]:
            status = "RECONNECTING"
        else:
            status = "NO DATA"
        link = f"[{status}]"
        if snap["reconnects"]:
            link += f" reconnects={snap['reconnects']} last drop {snap['last_drop']}"
        self._put(
            stdscr,
            1,
            0,
            f" frames={snap['frames']:<8d} fps={snap['fps']:6.1f}  dt={snap['frame_dt'] * 1e3:6.2f}ms  "
            f"crc_err={snap['crc_errors']:<5d} resync={snap['resyncs']:<5d} "
            f"board_ts={snap['board_ts_ms']:<10d} tactile={seen}/{len(snap['tactiles'])} "
            f"{link}",
            self._color(1 if live else 3, bold=True),
        )

        period = snap["period_ms"]
        period_s = f"{period:5.2f}ms ({1000 / period:5.1f} Hz)" if period else "learning..."
        expected = snap["frames"] + snap["dropped"]
        pct = 100.0 * snap["dropped"] / expected if expected else 0.0
        health = (
            f" period={period_s}  dropped={snap['dropped']} ({pct:.2f}%) in {snap['gaps']} gaps  "
            f"longest gap={snap['longest_gap_ms']}ms  board resets={snap['board_resets']}  "
            f"glitches={snap['glitches']}"
        )
        if snap["last_glitch"]:
            idx, what, when = snap["last_glitch"]
            health += f" (last: #{idx:02d} {what.replace(chr(0xB0), DEG)} at {when})"
        clean = not (snap["dropped"] or snap["board_resets"] or snap["glitches"])
        self._put(stdscr, 2, 0, health, self._color(1 if clean else 2))

        limit = height - 1
        y = 3
        if self.view == VIEW_RAW:
            self._draw_raw(stdscr, y, snap, width, limit)
        elif self.view == VIEW_TACTILE:
            self._draw_tactile(stdscr, y, snap, width, limit)
        else:
            if self.view in (VIEW_ENCODERS, VIEW_BOTH):
                y = self._draw_encoders(stdscr, y, snap, width, limit)
            if self.view == VIEW_BOTH:
                needed = len(snap["tactiles"]) + 3
                if y + needed <= limit:
                    y = self._draw_tactile(stdscr, y + 1, snap, width, limit)
                else:
                    self._put(
                        stdscr,
                        min(y, limit - 1),
                        1,
                        f"Terminal too short for the tactile table "
                        f"(needs {needed} more rows) - press 2 to show it alone.",
                        self._color(2),
                    )

        scale = "auto" if self.autoscale else f"{self.args.vmin:g}..{self.args.vmax:g}"
        footer = (
            f" q quit | 1/2/3/4 view={VIEW_NAMES[self.view]} | z tare | Z clear | r reset | "
            f"a scale ({scale}) | space {'resume' if self.frozen else 'freeze'}"
        )
        if width < FULL_WIDTH and self.view != VIEW_ENCODERS:
            footer = f" q quit | 1/2/3/4 view | z tare | r reset | widen to {FULL_WIDTH} cols for all tactile columns"
        self._put(stdscr, height - 1, 0, footer.ljust(width - 1), self._color(4, bold=True))
        if self._repaint:
            stdscr.redrawwin()
            self._repaint = False
        stdscr.refresh()

    @staticmethod
    def _put(stdscr, y, x, text, attr=curses.A_NORMAL):
        height, width = stdscr.getmaxyx()
        if y >= height or y < 0 or x >= width:
            return
        try:
            stdscr.addnstr(y, x, text, width - x - 1, attr)
        except curses.error:
            pass


def run_dashboard(state, port, args):
    curses.wrapper(Dashboard(state, port, args).run)
