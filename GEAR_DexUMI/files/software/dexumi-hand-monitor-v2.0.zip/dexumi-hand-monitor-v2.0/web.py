# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""
Browser front end of the DexUMI Hand Monitor.

Serves the page in web/ on localhost and streams every decoded frame to it as
Server-Sent Events, so the browser can draw live traces without any extra
packages on either side.
"""

import itertools
import json
import math
import os
import threading
import time
import uuid
import webbrowser
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

from recording_library import Library, RecordingError, safe_path
from umi_core import (
    ENCODER_COUNT,
    ENCODER_TO_TACTILE,
    FINGERS,
    JOINTS,
    TACTILE_LOCATIONS,
    TACTILE_ORDER,
    MonitorState,
    open_csv,
)

HERE = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(HERE, "web")
RECORDINGS_DIR = os.path.join(HERE, "recordings")
STATIC_FILES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/app.js": ("app.js", "application/javascript; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
}
TACTILE_KEYS = ("n1", "t1", "a1", "n2", "t2", "a2", "p1", "p2")
# Sensors the current hands do not carry; the tactile view hides them unless asked.
UNUSED_TACTILE = (30, 4, 7, 10, 13)
PUSH_INTERVAL = 1.0 / 60
STATUS_INTERVAL = 0.2


def _json_safe(value):
    """JSON has no inf/NaN; the browser would refuse the whole message."""
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return value


class WebState(MonitorState):
    """MonitorState that also keeps the last minute of frames for the charts."""

    HISTORY_FRAMES = 130 * 60

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.t0 = time.monotonic()
        self.samples = deque(maxlen=self.HISTORY_FRAMES)
        self.sample_seq = 0

    def on_frame(self, version, source, ts_ms, encoders, tactiles):
        now = time.monotonic()
        super().on_frame(version, source, ts_ms, encoders, tactiles, now)
        sample = [round(now - self.t0, 4), ts_ms, list(self.frame_values)]
        if tactiles:
            sample.append({str(sid): [s[k] for k in TACTILE_KEYS] for sid, s in tactiles.items()})
        with self.lock:
            self.sample_seq += 1
            self.samples.append((self.sample_seq, sample))

    def samples_since(self, seq):
        with self.lock:
            latest = self.sample_seq
            if seq > latest:  # client saw an earlier run of this server
                seq = 0
            if not self.samples or seq >= latest:
                return latest, []
            start = max(0, len(self.samples) - (latest - seq))
            return latest, [s for _, s in itertools.islice(self.samples, start, None)]


class Monitor:
    """Everything the request handlers need: state, reader, recording control."""

    def __init__(self, state, reader, port, args):
        self.state = state
        self.reader = reader
        self.port = port
        self.args = args
        self.boot = uuid.uuid4().hex[:8]
        self.recording = None
        self.stopping = threading.Event()
        self._record_lock = threading.Lock()
        self.library = Library(RECORDINGS_DIR, state.glitch_rate)
        if reader.csv_file is not None:
            self.recording = os.path.abspath(args.csv)

    def active_recording(self):
        """Name of the library file being written right now, if any."""
        if self.recording and os.path.dirname(self.recording) == RECORDINGS_DIR:
            return os.path.basename(self.recording)
        return None

    def config(self):
        return {
            "boot": self.boot,
            "port": self.port,
            "encoder_count": ENCODER_COUNT,
            "fingers": FINGERS,
            "joints": JOINTS,
            "encoder_to_tactile": ENCODER_TO_TACTILE,
            "tactile_order": TACTILE_ORDER,
            "tactile_locations": {str(k): v for k, v in TACTILE_LOCATIONS.items()},
            "unused_tactile": list(UNUSED_TACTILE),
            "vmin": self.args.vmin,
            "vmax": self.args.vmax,
            "glitch_rate": self.state.glitch_rate,
            "history_seconds": WebState.HISTORY_FRAMES / 130,
        }

    def status(self):
        snap = self.state.snapshot()
        snap["now"] = round(time.monotonic() - self.state.t0, 4)
        snap["recording"] = os.path.basename(self.recording) if self.recording else None
        snap["recorded_rows"] = self.reader.csv_rows
        return _json_safe(snap)

    def set_recording(self, on):
        with self._record_lock:
            if on and not self.recording:
                os.makedirs(RECORDINGS_DIR, exist_ok=True)
                path = os.path.join(RECORDINGS_DIR, time.strftime("dexumi-%Y%m%d-%H%M%S.csv"))
                self.reader.set_csv(open_csv(path))
                self.recording = path
            elif not on and self.recording:
                old = self.reader.set_csv(None)
                if old:
                    old.close()
                self.recording = None
        return self.recording

    def events_payload(self, events):
        wall_offset = time.time() - time.monotonic()
        return [
            {
                "seq": seq,
                "t": round(t - self.state.t0, 4),
                "wall": time.strftime("%H:%M:%S", time.localtime(t + wall_offset)),
                "kind": kind,
                "enc": enc,
                "text": text,
            }
            for seq, t, kind, enc, text in events
        ]


class Handler(BaseHTTPRequestHandler):
    monitor = None  # set by serve()
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        path, _, query = self.path.partition("?")
        params = {k: v[0] for k, v in parse_qs(query).items()}
        library = self.monitor.library
        try:
            if path == "/api/config":
                self._send_json(self.monitor.config())
            elif path == "/api/stream":
                self._stream(int(params.get("since", 0) or 0), int(params.get("events", 0) or 0))
            elif path == "/api/recordings":
                self._send_json(library.listing(self.monitor.active_recording()))
            elif path == "/api/recordings/summary":
                self._send_json(_json_safe(library.summary(params.get("name"))))
            elif path == "/api/recordings/load":
                self._send_json(_json_safe(library.load(params.get("name"))))
            elif path == "/api/recordings/file":
                name = params.get("name")
                with open(safe_path(RECORDINGS_DIR, name), "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/csv")
                self.send_header("Content-Disposition", f'attachment; filename="{name}"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self._get_static(path)
        except RecordingError as exc:
            self._send(400, json.dumps({"error": str(exc)}).encode(), "application/json")

    def _get_static(self, path):
        if path == "/favicon.ico":
            self._send(204, b"", "image/x-icon")
        elif path in STATIC_FILES:
            name, ctype = STATIC_FILES[path]
            with open(os.path.join(WEB_DIR, name), "rb") as f:
                self._send(200, f.read(), ctype)
        else:
            self._send(404, b"not found", "text/plain")

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(length) or b"{}")
        if self.path == "/api/reset":
            self.monitor.state.reset_stats()
            self._send_json({"ok": True})
        elif self.path == "/api/record":
            path = self.monitor.set_recording(bool(body.get("on")))
            self._send_json({"recording": os.path.basename(path) if path else None})
        elif self.path == "/api/recordings/delete":
            try:
                self.monitor.library.delete(body.get("name"), self.monitor.active_recording())
                self._send_json({"ok": True})
            except (RecordingError, OSError) as exc:
                self._send(400, json.dumps({"error": str(exc)}).encode(), "application/json")
        else:
            self._send(404, b"not found", "text/plain")

    def _send(self, code, data, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _send_json(self, obj):
        self._send(200, json.dumps(obj).encode(), "application/json")

    def _stream(self, since, event_seq):
        monitor = self.monitor
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.close_connection = True
        last_status = 0.0
        try:
            while not monitor.stopping.is_set():
                msg = {"boot": monitor.boot}
                since, samples = monitor.state.samples_since(since)
                msg["seq"] = since
                if samples:
                    msg["s"] = samples
                events = monitor.state.events_since(event_seq)
                if events:
                    event_seq = events[-1][0]
                    msg["ev"] = monitor.events_payload(events)
                now = time.monotonic()
                if now - last_status >= STATUS_INTERVAL:
                    msg["st"] = monitor.status()
                    last_status = now
                if len(msg) > 2:
                    self.wfile.write(b"data: " + json.dumps(msg, separators=(",", ":")).encode() + b"\n\n")
                    self.wfile.flush()
                time.sleep(PUSH_INTERVAL)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass


def _bind(first_port):
    for port in range(first_port, first_port + 20):
        try:
            return ThreadingHTTPServer(("127.0.0.1", port), Handler)
        except OSError:
            continue
    raise SystemExit(f"Could not open a local web port between {first_port} and {first_port + 19}.")


def serve(state, reader, port, args):
    """Run the web dashboard until Ctrl+C."""
    monitor = Monitor(state, reader, port, args)
    Handler.monitor = monitor
    server = _bind(args.http_port)
    server.daemon_threads = True
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    threading.Thread(target=server.serve_forever, name="http", daemon=True).start()

    print(f"Dashboard: {url}   (Ctrl+C here to quit)")
    if not args.no_browser:
        webbrowser.open(url)
    try:
        while True:
            snap = state.snapshot()
            live = snap["link_age"] is not None and snap["link_age"] < 0.5
            link = "LIVE" if live else ("RECONNECTING" if snap["error"] else "NO DATA")
            rec = f"REC {os.path.basename(monitor.recording)}" if monitor.recording else "not recording"
            line = (
                f"\r  {link:<12} {snap['fps']:6.1f} fps  dropped={snap['dropped']}  "
                f"resets={snap['board_resets']}  glitches={snap['glitches']}  {rec}"
            )
            if snap["port"] is None:
                line = "\r  WAITING for the board to be plugged in..."
            print(line.ljust(100), end="", flush=True)
            time.sleep(0.5)
    except KeyboardInterrupt:
        print()
    finally:
        monitor.stopping.set()
        server.shutdown()
        server.server_close()
