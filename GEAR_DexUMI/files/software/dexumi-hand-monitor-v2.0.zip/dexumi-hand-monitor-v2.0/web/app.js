// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

"use strict";

const $ = (id) => document.getElementById(id);
const CAPACITY = 16384; // samples kept per trace (~2.5 min at 106-120 Hz)
const GAP_S = 0.1; // break a trace when samples are further apart than this
const SERIES_COLORS = ["#4ea1ff", "#e8b04b", "#4cc38a", "#e5604f", "#b483f0", "#3cc7c7", "#e87dc0", "#c9c24a"];
const MARKER_COLORS = { glitch: "#e5604f", drop: "#e8b04b", reset: "#b483f0", link: "#7d8899" };
const TEXT_REFRESH_MS = 100;
const NO_DIRECTION = 65535; // the sensor's "no direction" value, sent while there is no tangential force
const TOAST_MS = 9000;
const narrowQuery = window.matchMedia("(max-width: 1099px)");

// ------------------------------------------------------------------ data --

class Ring {
  constructor(capacity = CAPACITY) {
    this.t = new Float64Array(capacity);
    this.v = new Float64Array(capacity);
    this.capacity = capacity;
    this.len = 0;
    this.head = 0;
  }
  push(t, v) {
    this.t[this.head] = t;
    this.v[this.head] = v;
    this.head = (this.head + 1) % this.capacity;
    if (this.len < this.capacity) this.len++;
  }
  index(i) { // i = 0 is the oldest sample
    return (this.head - this.len + i + this.capacity) % this.capacity;
  }
  firstAtOrAfter(t0) {
    let lo = 0, hi = this.len;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (this.t[this.index(mid)] < t0) lo = mid + 1; else hi = mid;
    }
    return lo;
  }
  clear() { this.len = 0; this.head = 0; }
}

// A whole recorded trace, with the same reading interface as Ring.
class ArraySeries extends Ring {
  constructor(times, values) {
    super(0);
    this.t = times;
    this.v = Float64Array.from(values, (v) => (v === null ? NaN : v));
    this.len = values.length;
  }
  index(i) { return i; }
}

const S = {
  cfg: null,
  status: null,
  heldStatus: null,
  boot: null,
  seq: 0,
  eventSeq: 0,
  connected: false,
  clockOffset: null,
  enc: [],
  tac: {},
  live: { enc: [], tac: {} }, // newest reading of every sensor, updated per frame
  held: null, // copy of `live` while paused
  events: [],
  eventsDirty: true,
  view: "encoders",
  windowSec: 10,
  autoscale: true,
  paused: false,
  pausedAt: 0,
  tare: null,
  tacTare: null,
  focus: [],
  lastText: 0,
  showUnused: localStorage.getItem("showUnusedTactile") === "1",
  replay: null, // the loaded recording while replaying, else null
  library: null,
  narrow: narrowQuery.matches, // half-screen layout
  allStats: false,
  eventsOpen: false,
  toastTimer: null,
};

// Charts read from the replayed recording when there is one, else the live buffers.
function dataSource() {
  return S.replay || S;
}

function tacRings(id) {
  if (!S.tac[id]) S.tac[id] = { n1: new Ring(), n2: new Ring(), t1: new Ring() };
  return S.tac[id];
}

function resetBuffers() {
  S.enc.forEach((r) => r.clear());
  Object.values(S.tac).forEach((r) => { r.n1.clear(); r.n2.clear(); r.t1.clear(); });
  S.live = { enc: [], tac: {} };
  S.events = [];
  S.eventsDirty = true;
  S.seq = 0;
  S.eventSeq = 0;
}

function ingest(sample) {
  const [t, , enc, tac] = sample;
  for (let i = 0; i < enc.length && i < S.enc.length; i++) {
    S.enc[i].push(t, enc[i] === null ? NaN : enc[i]);
    S.live.enc[i] = enc[i]; // null: no valid reading in this frame
  }
  if (tac) {
    for (const id in tac) {
      const d = tac[id];
      S.live.tac[id] = d;
      const r = tacRings(id);
      r.n1.push(t, d[0]);
      r.t1.push(t, d[1]);
      r.n2.push(t, d[3]);
    }
  }
}

function onMessage(ev) {
  const m = JSON.parse(ev.data);
  if (S.boot !== null && m.boot !== S.boot) {
    // The monitor was restarted: its sequence numbers start over.
    resetBuffers();
    S.boot = m.boot;
    reconnect();
    return;
  }
  S.boot = m.boot;
  if (m.s) m.s.forEach(ingest);
  S.seq = m.seq;
  if (m.ev) {
    for (const e of m.ev) S.events.push(e);
    if (S.eventSeq) toast(m.ev); // not for the backlog sent on (re)connect
    S.eventSeq = m.ev[m.ev.length - 1].seq;
    if (S.events.length > 500) S.events.splice(0, S.events.length - 500);
    S.eventsDirty = true;
  }
  if (m.st) {
    S.status = m.st;
    S.clockOffset = m.st.now - performance.now() / 1000;
  }
}

let source = null;
function connect() {
  source = new EventSource(`/api/stream?since=${S.seq}&events=${S.eventSeq}`);
  source.onopen = () => { S.connected = true; };
  source.onmessage = onMessage;
  source.onerror = () => {
    S.connected = false;
    source.close();
    setTimeout(connect, 1000);
  };
}
function reconnect() {
  if (source) source.close();
  connect();
}

function serverNow() {
  return S.clockOffset === null ? 0 : performance.now() / 1000 + S.clockOffset;
}

async function post(path, body = {}) {
  const res = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  return res.json();
}

// ------------------------------------------------------------- drawing --

function fitCanvas(canvas) {
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth, h = canvas.clientHeight;
  const pw = Math.max(1, Math.round(w * dpr)), ph = Math.max(1, Math.round(h * dpr));
  if (canvas.width !== pw || canvas.height !== ph) {
    canvas.width = pw;
    canvas.height = ph;
  }
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  return [ctx, w, h];
}

function niceStep(span, count) {
  const raw = span / Math.max(1, count);
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  for (const m of [1, 2, 2.5, 5, 10]) if (m * mag >= raw) return m * mag;
  return 10 * mag;
}

function visibleRange(rings, tStart, tEnd) {
  let lo = Infinity, hi = -Infinity;
  for (const ring of rings) {
    for (let k = ring.firstAtOrAfter(tStart); k < ring.len; k++) {
      const i = ring.index(k);
      if (ring.t[i] > tEnd) break;
      const v = ring.v[i];
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
  }
  return Number.isFinite(lo) ? [lo, hi] : null;
}

function padRange(range, minSpan) {
  let [lo, hi] = range;
  if (hi - lo < minSpan) {
    const mid = (lo + hi) / 2;
    lo = mid - minSpan / 2;
    hi = mid + minSpan / 2;
  }
  const pad = (hi - lo) * 0.08;
  return [lo - pad, hi + pad];
}

function encoderRange(rings, tStart, tEnd) {
  if (!S.autoscale) return [S.cfg.vmin, S.cfg.vmax];
  const range = visibleRange(rings, tStart, tEnd);
  return range ? padRange(range, 2) : [S.cfg.vmin, S.cfg.vmax];
}

// Plots a ring as a polyline, keeping at most four vertices per pixel column
// (first, min, max, last) so a one-frame spike stays visible at any zoom.
function drawSeries(ctx, ring, tStart, tEnd, plot, yOf, color, wraps) {
  if (!ring.len) return;
  const sx = plot.w / (tEnd - tStart);
  let k = Math.max(0, ring.firstAtOrAfter(tStart) - 1);
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  ctx.lineJoin = "round";
  ctx.beginPath();
  let pen = false, prevT = -Infinity, prevV = NaN;
  let col = null, bx = 0, first = 0, min = 0, max = 0, last = 0;
  const flush = () => {
    if (col === null) return;
    if (pen) ctx.lineTo(bx, first); else { ctx.moveTo(bx, first); pen = true; }
    if (min !== first || max !== first) { ctx.lineTo(bx, min); ctx.lineTo(bx, max); }
    ctx.lineTo(bx, last);
    col = null;
  };
  for (; k < ring.len; k++) {
    const i = ring.index(k);
    const t = ring.t[i], v = ring.v[i];
    if (t > tEnd) break;
    const broken = !Number.isFinite(v) || t - prevT > GAP_S || (wraps && Math.abs(v - prevV) > 180);
    if (broken) { flush(); pen = false; }
    prevT = t;
    prevV = v;
    if (!Number.isFinite(v)) continue;
    const x = plot.x + (t - tStart) * sx, y = yOf(v);
    const c = Math.floor(x);
    if (c !== col) {
      flush();
      col = c; bx = x; first = min = max = last = y;
    } else {
      if (y < min) min = y;
      if (y > max) max = y;
      last = y;
    }
  }
  flush();
  ctx.stroke();
}

function drawMarkers(ctx, plot, tStart, tEnd, encoders) {
  const sx = plot.w / (tEnd - tStart);
  for (const e of dataSource().events) {
    if (e.t < tStart || e.t > tEnd) continue;
    if (e.kind === "glitch" && !encoders.includes(e.enc)) continue;
    const x = Math.round(plot.x + (e.t - tStart) * sx) + 0.5;
    ctx.strokeStyle = MARKER_COLORS[e.kind] || "#888";
    ctx.globalAlpha = e.kind === "glitch" ? 0.9 : 0.6;
    ctx.lineWidth = 1;
    ctx.setLineDash(e.kind === "glitch" ? [] : [3, 3]);
    ctx.beginPath();
    ctx.moveTo(x, plot.y);
    ctx.lineTo(x, plot.y + plot.h);
    ctx.stroke();
  }
  ctx.setLineDash([]);
  ctx.globalAlpha = 1;
}

// Shades the stretches where an encoder sent no valid angle and labels them NaN.
function drawNanSpans(ctx, ring, tStart, tEnd, plot) {
  if (!ring.len) return;
  const sx = plot.w / (tEnd - tStart);
  const spans = [];
  let start = null, prevT = null;
  for (let k = Math.max(0, ring.firstAtOrAfter(tStart) - 1); k < ring.len; k++) {
    const i = ring.index(k);
    const t = ring.t[i];
    if (t > tEnd) break;
    const nan = !Number.isFinite(ring.v[i]);
    if (start !== null && (!nan || t - prevT > GAP_S)) { spans.push([start, nan ? prevT : t]); start = null; }
    if (nan && start === null) start = t;
    prevT = t;
  }
  if (start !== null) spans.push([start, prevT]);
  ctx.font = "bold 11px ui-monospace, Menlo, monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  for (const [a, b] of spans) {
    const x0 = plot.x + Math.max(0, (a - tStart) * sx), x1 = plot.x + Math.min(plot.w, (b - tStart) * sx);
    const w = Math.max(1, x1 - x0);
    ctx.fillStyle = "rgba(229, 96, 79, 0.13)";
    ctx.fillRect(x0, plot.y, w, plot.h);
    if (w > 28) {
      ctx.fillStyle = "rgba(229, 96, 79, 0.85)";
      ctx.fillText("NaN", x0 + w / 2, plot.y + plot.h / 2);
    }
  }
}

function drawYGrid(ctx, plot, lo, hi, labels, unit) {
  const step = S.autoscale || unit !== "°" ? niceStep(hi - lo, plot.h > 150 ? 6 : 2) : 90;
  ctx.font = "10px ui-monospace, Menlo, monospace";
  ctx.textBaseline = "middle";
  for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-9; v += step) {
    const y = Math.round(plot.y + plot.h - ((v - lo) / (hi - lo)) * plot.h) + 0.5;
    ctx.strokeStyle = "#263040";
    ctx.beginPath();
    ctx.moveTo(plot.x, y);
    ctx.lineTo(plot.x + plot.w, y);
    ctx.stroke();
    if (labels) {
      ctx.fillStyle = "#7d8899";
      ctx.textAlign = "right";
      const digits = step < 1 ? 2 : step < 10 ? 1 : 0;
      ctx.fillText(v.toFixed(digits) + unit, plot.x - 4, y);
    }
  }
}

function drawTimeAxis(ctx, plot, tStart, tEnd) {
  const span = tEnd - tStart;
  const step = niceStep(span, 10);
  ctx.font = "10px ui-monospace, Menlo, monospace";
  ctx.textBaseline = "top";
  ctx.textAlign = "center";
  for (let s = 0; s <= span + 1e-9; s += step) {
    const x = Math.round(plot.x + plot.w - (s / span) * plot.w) + 0.5;
    ctx.strokeStyle = "#1f2733";
    ctx.beginPath();
    ctx.moveTo(x, plot.y);
    ctx.lineTo(x, plot.y + plot.h);
    ctx.stroke();
    ctx.fillStyle = "#7d8899";
    const now = S.replay ? fmtClock(tEnd) : "now";
    ctx.fillText(s === 0 ? now : `-${+s.toFixed(1)}s`, x, plot.y + plot.h + 4);
  }
}

function drawMiniLabels(ctx, w, h, lo, hi, digits, unit) {
  ctx.font = "10px ui-monospace, Menlo, monospace";
  ctx.fillStyle = "rgba(125,136,153,0.8)";
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.fillText(hi.toFixed(digits) + unit, 2, 0);
  ctx.textBaseline = "bottom";
  ctx.fillText(lo.toFixed(digits) + unit, 2, h);
}

function drawEncoderChart(canvas, ids, tStart, tEnd, big) {
  const [ctx, w, h] = fitCanvas(canvas);
  const plot = big ? { x: 52, y: 6, w: w - 60, h: h - 26 } : { x: 0, y: 12, w: w, h: h - 24 };
  const rings = ids.map((i) => dataSource().enc[i]);
  const [lo, hi] = encoderRange(rings, tStart, tEnd);
  const yOf = (v) => plot.y + plot.h - ((v - lo) / (hi - lo)) * plot.h;
  if (big) drawTimeAxis(ctx, plot, tStart, tEnd);
  drawYGrid(ctx, plot, lo, hi, big, "°");
  if (!big) drawNanSpans(ctx, rings[0], tStart, tEnd, plot);
  drawMarkers(ctx, plot, tStart, tEnd, ids);
  ctx.save();
  ctx.beginPath();
  ctx.rect(plot.x, plot.y - 1, plot.w, plot.h + 2);
  ctx.clip();
  ids.forEach((id, n) => {
    const color = big ? SERIES_COLORS[n % SERIES_COLORS.length] : "#4ea1ff";
    drawSeries(ctx, rings[n], tStart, tEnd, plot, yOf, color, true);
  });
  ctx.restore();
  if (!big) drawMiniLabels(ctx, w, h, lo, hi, S.autoscale ? 1 : 0, "°");
}

function drawTactileChart(canvas, id, tStart, tEnd) {
  const [ctx, w, h] = fitCanvas(canvas);
  const plot = { x: 0, y: 12, w: w, h: h - 24 };
  const r = dataSource().tac[id];
  if (!r) return;
  const range = visibleRange([r.n1, r.n2, r.t1], tStart, tEnd);
  const [lo, hi] = range ? padRange(range, 10) : [0, 100];
  const yOf = (v) => plot.y + plot.h - ((v - lo) / (hi - lo)) * plot.h;
  drawYGrid(ctx, plot, lo, hi, false, "");
  drawSeries(ctx, r.n1, tStart, tEnd, plot, yOf, "#4ea1ff", false);
  drawSeries(ctx, r.n2, tStart, tEnd, plot, yOf, "#4cc38a", false);
  drawSeries(ctx, r.t1, tStart, tEnd, plot, yOf, "#e8b04b", false);
  drawMiniLabels(ctx, w, h, lo, hi, 0, "");
}

// ----------------------------------------------------------------- DOM --

const cards = [];
const tacCards = {};
const tacRows = {};

function fmt(v, digits = 2) {
  return v === null || v === undefined ? "--" : v.toFixed(digits);
}
function wrapDelta(d) {
  return ((d + 180) % 360 + 360) % 360 - 180;
}
function setText(el, text) {
  if (el.textContent !== text) el.textContent = text;
}
function fmtClock(s) {
  const m = Math.floor(s / 60);
  return `${m}:${(s - m * 60).toFixed(1).padStart(4, "0")}`;
}
function fmtDuration(s) {
  return s >= 60 ? `${Math.floor(s / 60)} min ${Math.round(s % 60)} s` : `${s.toFixed(1)} s`;
}
function fmtBytes(n) {
  return n >= 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} kB`;
}
function escapeHtml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
}

function buildEncoderGrid() {
  const grid = $("grid");
  const { fingers, joints, encoder_to_tactile: e2t } = S.cfg;
  fingers.forEach((finger, f) => {
    const label = document.createElement("div");
    label.className = "finger";
    label.textContent = finger;
    grid.appendChild(label);
    joints.forEach((joint, j) => {
      const id = f * joints.length + j;
      const card = document.createElement("div");
      card.className = "card dead";
      card.innerHTML = `
        <div class="card-head"><span class="cid">#${String(id).padStart(2, "0")}</span>
          <span class="cname">${joint}</span><span class="badge" hidden></span></div>
        <div class="card-value"><span class="val">--</span><span class="delta"></span></div>
        <canvas class="spark"></canvas>
        <div class="card-foot"><span class="mm"></span><span class="good"></span>
          <span>${e2t[id] >= 0 ? "tac " + e2t[id] : ""}</span></div>`;
      card.addEventListener("click", () => toggleFocus(id));
      grid.appendChild(card);
      cards[id] = {
        el: card,
        val: card.querySelector(".val"),
        delta: card.querySelector(".delta"),
        badge: card.querySelector(".badge"),
        canvas: card.querySelector(".spark"),
        mm: card.querySelector(".mm"),
        good: card.querySelector(".good"),
      };
    });
  });
}

function buildTactile() {
  const table = $("tac-table");
  table.innerHTML = `<thead><tr><th>ID</th><th>Location</th><th>Encoder</th><th>Normal 1</th><th>Tang 1</th>
    <th>Dir 1</th><th>Normal 2</th><th>Tang 2</th><th>Dir 2</th><th>Prox 1</th><th>Prox 2</th>
    <th>Max N1</th><th>Max N2</th><th>Hz</th></tr></thead><tbody></tbody>`;
  const body = table.querySelector("tbody");
  const grid = $("tac-grid");
  for (const id of S.cfg.tactile_order) {
    const loc = S.cfg.tactile_locations[id] || `#${id}`;
    const enc = S.cfg.encoder_to_tactile.indexOf(id);
    const tr = document.createElement("tr");
    tr.className = "stale";
    tr.innerHTML = `<td>${id}</td><td>${loc}</td><td>#${String(enc).padStart(2, "0")}</td>` + "<td></td>".repeat(11);
    body.appendChild(tr);
    tacRows[id] = Array.from(tr.children).slice(3);
    for (const i of [2, 5]) tacRows[id][i].title = "— = 65535 from the sensor: no direction, because there is no tangential force";
    tacRows[id].row = tr;

    const card = document.createElement("div");
    card.className = "card tac-card dead";
    card.innerHTML = `<div class="card-head"><span class="cid">${id}</span><span class="cname">${loc}</span>
      <span class="muted state">no data</span></div><canvas class="spark"></canvas>`;
    grid.appendChild(card);
    tacCards[id] = { el: card, canvas: card.querySelector("canvas"), state: card.querySelector(".state") };
  }
  applyUnused();
}

function isHidden(id) {
  return !S.showUnused && S.cfg.unused_tactile.includes(id);
}

function applyUnused() {
  for (const id of S.cfg.tactile_order) {
    tacRows[id].row.hidden = isHidden(id);
    tacCards[id].el.hidden = isHidden(id);
  }
  const n = S.cfg.unused_tactile.length;
  setText($("btn-unused"), S.showUnused ? "Hide unused sensors (u)" : `Show unused sensors: ${n} hidden (u)`);
  $("btn-unused").title = S.cfg.unused_tactile.map((id) => S.cfg.tactile_locations[id] || id).join(", ");
}

function toggleUnused() {
  S.showUnused = !S.showUnused;
  localStorage.setItem("showUnusedTactile", S.showUnused ? "1" : "0");
  applyUnused();
}

function toggleFocus(id) {
  const i = S.focus.indexOf(id);
  if (i >= 0) S.focus.splice(i, 1); else S.focus.push(id);
  renderFocusLegend();
}

function renderFocusLegend() {
  $("focus").hidden = S.focus.length === 0;
  const legend = $("focus-legend");
  legend.innerHTML = "";
  S.focus.forEach((id, n) => {
    const chip = document.createElement("span");
    chip.className = "chip";
    const name = `${S.cfg.fingers[Math.floor(id / 3)]} ${S.cfg.joints[id % 3]}`;
    chip.innerHTML = `<i style="background:${SERIES_COLORS[n % SERIES_COLORS.length]}"></i>#${String(id).padStart(2, "0")} ${name} &times;`;
    chip.title = "Remove from chart";
    chip.addEventListener("click", () => toggleFocus(id));
    legend.appendChild(chip);
  });
  cards.forEach((c, id) => c.el.classList.toggle("selected", S.focus.includes(id)));
}

function linkState(st) {
  if (!S.connected) return ["MONITOR STOPPED", "pill-bad"];
  if (!st) return ["CONNECTING", "pill-warn"];
  if (!st.port) return ["WAITING FOR BOARD", "pill-warn"];
  if (st.link_age !== null && st.link_age < 0.5) return ["LIVE", "pill-good"];
  if (st.error) return ["RECONNECTING", "pill-warn"];
  return ["NO DATA", "pill-bad"];
}

// One header statistic. In the half-screen layout only the key ones are shown,
// unless "more" is pressed.
function statItem(k, v, cls = "", key = false) {
  if (S.narrow && !S.allStats && !key) return "";
  return `<span><span class="k">${k}</span> <span class="${cls}">${v}</span></span>`;
}

function renderHeader(st) {
  const [label, cls] = linkState(S.status);
  const link = $("link");
  setText(link, label);
  link.className = `pill ${cls}`;
  if (S.status) setText($("port"), S.status.port || "");
  $("paused").hidden = !S.paused;
  const live = S.status;
  const rec = $("rec");
  rec.hidden = !(live && live.recording);
  if (live && live.recording) setText(rec, `REC ${live.recording} (${live.recorded_rows.toLocaleString()} rows)`);
  const btn = $("btn-record");
  btn.classList.toggle("on", !!(live && live.recording));
  setText(btn, live && live.recording ? (S.narrow ? "\u25A0 Stop" : "\u25A0 Stop recording") : "\u25CF Record");
  updateTareButton();
  const pill = $("replay-pill");
  pill.hidden = !S.replay;
  if (S.replay) {
    setText(pill, `REPLAY ${S.replay.name}`);
    renderReplayStats();
    return;
  }
  if (!st) return;
  const expected = st.frames + st.dropped;
  const pct = expected ? (100 * st.dropped / expected).toFixed(2) : "0.00";
  const tacLive = st.tactiles.filter((t) => !t.stale).length;
  const item = statItem;
  const html = [
    item("fps", st.fps.toFixed(1), "", true),
    item("period", st.period_ms ? `${st.period_ms.toFixed(2)} ms` : "learning"),
    item("frames", st.frames.toLocaleString()),
    item("dropped", `${st.dropped} (${pct}%)`, st.dropped ? "warn" : "", true),
    item("longest gap", `${st.longest_gap_ms} ms`),
    item("resets", st.board_resets, st.board_resets ? "warn" : ""),
    item("glitches", st.glitches, st.glitches ? "bad" : "", true),
    item("crc err", st.crc_errors, st.crc_errors ? "warn" : ""),
    item("resync", st.resyncs),
    item("reconnects", st.reconnects, st.reconnects ? "warn" : "", true),
    item("tactile", `${tacLive}/${st.tactiles.length}`),
    item("uptime", `${(st.board_ts_ms / 1000).toFixed(1)} s`),
  ].join("");
  const stats = $("stats");
  if (stats.innerHTML !== html) stats.innerHTML = html;
}

// Values come from the per-frame stream and are redrawn every screen refresh;
// the statistics around them come from the status message, ~10 times a second.

function renderCardValues(live) {
  cards.forEach((c, id) => {
    const value = live.enc[id];
    const nan = value === null;
    const seen = value !== undefined && !nan;
    setText(c.val, nan ? "NaN" : seen ? `${value.toFixed(2)}°` : "--");
    c.val.classList.toggle("nan", nan);
    const tare = S.tare && S.tare[id];
    const d = seen && tare !== null && tare !== undefined ? wrapDelta(value - tare) : null;
    setText(c.delta, d === null ? "" : `\u0394 ${d >= 0 ? "+" : ""}${d.toFixed(2)}°`);
  });
}

function renderCardStats(st) {
  st.encoders.forEach((row, id) => {
    const c = cards[id];
    if (!c) return;
    const seen = row.value !== null;
    c.el.classList.toggle("dead", !seen || (row.stale && row.good === 0));
    c.el.classList.toggle("stale", seen && row.stale);
    const span = S.narrow ? "" : ` (${fmt(row.max - row.min)})`;
    setText(c.mm, row.min !== null ? `${fmt(row.min)}…${fmt(row.max)}${span}` : "no signal");
    setText(c.good, row.good !== null ? `${Math.round(row.good * 100)}% good` : "");
    c.badge.hidden = !row.glitches;
    setText(c.badge, `${row.glitches} glitch${row.glitches === 1 ? "" : "es"}`);
  });
}

function renderTactileValues(live) {
  for (const id of S.cfg.tactile_order) {
    const cells = tacRows[id];
    const d = live.tac[id]; // n1, t1, a1, n2, t2, a2, p1, p2
    if (!d) continue;
    const base = S.tacTare && S.tacTare[id];
    const values = [
      base ? d[0] - base.n1 : d[0], d[1], d[2],
      base ? d[3] - base.n2 : d[3], d[4], d[5], d[6], d[7],
    ];
    values.forEach((v, i) => {
      const direction = i === 2 || i === 5;
      setText(cells[i], direction ? (v === NO_DIRECTION ? "—" : String(v)) : v.toLocaleString());
    });
  }
}

function renderTactileStats(st) {
  for (const row of st.tactiles) {
    const cells = tacRows[row.id];
    if (!cells) continue;
    cells.row.className = row.stale ? "stale" : "";
    const s = row.sample;
    const stats = s ? [row.n1_max.toLocaleString(), row.n2_max.toLocaleString(), row.hz.toFixed(1)] : ["", "", ""];
    stats.forEach((v, i) => setText(cells[8 + i], v));
    const card = tacCards[row.id];
    card.el.classList.toggle("dead", !s);
    setText(card.state, !s ? "no data" : row.stale ? "stale" : `${row.hz.toFixed(0)} Hz`);
  }
}

// Live: the newest events first. Replay: events up to the playhead, newest first,
// each one clickable to move the playhead to it.
function renderEvents() {
  const R = S.replay;
  const events = dataSource().events;
  let shown = events.length;
  if (R) {
    shown = lastAtOrBefore(R.eventTimes, R.pos) + 1;
    if (shown !== R.eventsShown) { R.eventsShown = shown; S.eventsDirty = true; }
  }
  if (!S.eventsDirty) return;
  S.eventsDirty = false;
  const log = $("event-log");
  setText($("event-title"), R ? "Events in recording" : "Events");
  setText($("event-count"), R ? `${shown} / ${events.length}` : events.length ? `${events.length}` : "");
  setText($("events-badge"), R ? `${shown}/${events.length}` : `${events.length}`);
  if (!shown) {
    log.innerHTML = R
      ? `<li class="empty">${events.length ? "No events before the playhead yet." : "No glitches, dropped frames or board resets in this recording."}</li>`
      : '<li class="empty">No glitches, dropped frames or board resets so far.</li>';
    return;
  }
  const items = [];
  for (let i = shown - 1; i >= 0 && items.length < 200; i--) {
    const e = events[i];
    const who = e.enc === null ? "" : `#${String(e.enc).padStart(2, "0")} `;
    const when = R ? fmtClock(e.t) : e.wall;
    const attrs = R ? ` class="seekable" data-t="${e.t}" title="${e.wall} — click to jump here"` : "";
    items.push(`<li${attrs}><span class="when">${when}</span><span class="kind kind-${e.kind}">${e.kind}</span>` +
               `<span>${who}${escapeHtml(e.text)}</span></li>`);
  }
  log.innerHTML = items.join("");
}

// ---------------------------------------------------------------- loop --

function frame() {
  requestAnimationFrame(frame);
  if (!S.cfg) return;
  const nowMs = performance.now();
  let st, live, tEnd;
  if (S.replay) {
    advanceReplay(nowMs);
    live = replayValues();
    st = replayStatus(live);
    tEnd = S.replay.pos;
    drawTimeline();
  } else {
    st = S.paused ? S.heldStatus : S.status;
    live = S.paused ? S.held : S.live;
    tEnd = S.paused ? S.pausedAt : serverNow();
  }
  S.shown = live;
  const tStart = tEnd - S.windowSec;

  if (nowMs - S.lastText > TEXT_REFRESH_MS) {
    S.lastText = nowMs;
    renderHeader(st);
    if (st) {
      if (S.view === "encoders") renderCardStats(st);
      if (S.view === "tactile") renderTactileStats(st);
    }
    if (!S.paused || S.replay) renderEvents();
  }

  if (S.view === "encoders") {
    renderCardValues(live);
    if (S.focus.length) drawEncoderChart($("focus-canvas"), S.focus, tStart, tEnd, true);
    cards.forEach((c, id) => drawEncoderChart(c.canvas, [id], tStart, tEnd, false));
  } else if (S.view === "tactile") {
    renderTactileValues(live);
    for (const id of S.cfg.tactile_order) {
      if (!isHidden(id)) drawTactileChart(tacCards[id].canvas, String(id), tStart, tEnd);
    }
  }
}

// -------------------------------------------------------------- replay --

function lastAtOrBefore(times, t) { // index of the last entry <= t, or -1
  let lo = 0, hi = times.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (times[mid] <= t) lo = mid + 1; else hi = mid;
  }
  return lo - 1;
}

async function startReplay(name) {
  setLibraryNote(`Loading ${name}…`);
  const res = await fetch(`/api/recordings/load?name=${encodeURIComponent(name)}`);
  const d = await res.json();
  if (!res.ok) { setLibraryNote(d.error || "Could not load the recording."); return; }
  setLibraryNote("");
  const times = Float64Array.from(d.t);
  const tac = {};
  for (const id in d.tac) {
    const [n1, t1, , n2] = d.tac[id];
    tac[id] = { n1: new ArraySeries(times, n1), n2: new ArraySeries(times, n2), t1: new ArraySeries(times, t1) };
  }
  S.replay = {
    name,
    summary: d.summary,
    times,
    duration: d.summary.duration,
    encCols: d.enc,
    tacCols: d.tac,
    enc: d.enc.map((col) => new ArraySeries(times, col)),
    tac,
    events: d.events,
    eventTimes: d.events.map((e) => e.t),
    eventsShown: -1,
    pos: 0,
    playing: true,
    speed: Number($("speed").value),
    lastPerf: performance.now(),
  };
  if (S.paused) togglePause();
  S.tare = null;
  S.tacTare = null;
  document.body.classList.add("replaying");
  $("transport").hidden = false;
  setPlaying(true);
  S.eventsDirty = true;
  setView("encoders");
}

function exitReplay() {
  S.replay = null;
  document.body.classList.remove("replaying");
  $("transport").hidden = true;
  S.tare = null;
  S.tacTare = null;
  S.eventsDirty = true;
  S.lastText = 0;
}

function advanceReplay(nowMs) {
  const R = S.replay;
  if (R.playing) {
    R.pos += ((nowMs - R.lastPerf) / 1000) * R.speed;
    if (R.pos >= R.duration) { R.pos = R.duration; setPlaying(false); }
  }
  R.lastPerf = nowMs;
}

function setPlaying(on) {
  const R = S.replay;
  if (!R) return;
  if (on && R.pos >= R.duration) R.pos = 0; // play again from the start
  R.playing = on;
  R.lastPerf = performance.now();
  setText($("btn-play"), on ? "Pause (space)" : "Play (space)");
}

function seek(t) {
  const R = S.replay;
  R.pos = Math.min(R.duration, Math.max(0, t));
  R.lastPerf = performance.now();
  S.lastText = 0;
}

// The reading of every sensor at the playhead, shaped like S.live.
function replayValues() {
  const R = S.replay;
  const i = lastAtOrBefore(R.times, R.pos);
  const out = { enc: [], tac: {}, index: i };
  if (i < 0) return out;
  R.encCols.forEach((col, id) => { out.enc[id] = col[i]; });
  for (const id in R.tacCols) {
    const cols = R.tacCols[id];
    if (cols[0][i] !== null) out.tac[id] = cols.map((c) => c[i]);
  }
  return out;
}

// Whole-recording statistics, shaped like the live status the cards and table read.
function replayStatus(live) {
  const R = S.replay, sum = R.summary;
  return {
    encoders: sum.encoders.map((e, id) => ({
      value: e.good ? 0 : null,
      stale: !!e.good && live.enc[id] == null,
      good: e.good,
      min: e.min,
      max: e.max,
      glitches: e.glitches,
    })),
    tactiles: S.cfg.tactile_order.map((id) => {
      const t = sum.tactile[id] || { frames: 0, n1_max: 0, n2_max: 0 };
      return {
        id,
        sample: t.frames > 0,
        stale: t.frames > 0 && !live.tac[id],
        n1_max: t.n1_max,
        n2_max: t.n2_max,
        hz: R.duration > 0 ? t.frames / R.duration : 0,
      };
    }),
  };
}

function healthItems(sum) {
  return [
    ["dropped", sum.dropped, "warn"],
    ["resets", sum.board_resets, "warn"],
    ["outages", sum.outages, "warn"],
    ["glitches", sum.glitches, "bad"],
  ];
}

function renderReplayStats() {
  const R = S.replay, sum = R.summary;
  const item = statItem;
  const html = [
    item("recorded", sum.start_str || "?"),
    item("length", fmtDuration(sum.duration), "", true),
    item("frames", sum.frames.toLocaleString()),
    item("fps", sum.fps.toFixed(1)),
    item("period", sum.period_ms ? `${sum.period_ms.toFixed(2)} ms` : "?"),
    item("longest gap", `${sum.longest_gap_ms} ms`),
    ...healthItems(sum).map(([k, v, cls]) => item(k, v, v ? cls : "", k === "dropped" || k === "glitches")),
    item("encoders", `${sum.live_encoders}/${sum.encoders.length}`),
  ].join("");
  const stats = $("stats");
  if (stats.innerHTML !== html) stats.innerHTML = html;
  setText($("replay-time"), `${fmtClock(R.pos)} / ${fmtClock(R.duration)}`);
}

// Overview of the whole recording: event ticks, the charted window and the playhead.
function drawTimeline() {
  const R = S.replay;
  const canvas = $("timeline");
  const [ctx, w, h] = fitCanvas(canvas);
  const span = Math.max(R.duration, 1e-6);
  const xOf = (t) => (t / span) * w;
  ctx.fillStyle = "#1a212c";
  ctx.fillRect(0, 0, w, h);
  for (const e of R.events) {
    ctx.fillStyle = MARKER_COLORS[e.kind] || "#888";
    ctx.globalAlpha = e.kind === "glitch" ? 0.9 : 0.6;
    ctx.fillRect(Math.round(xOf(e.t)), e.kind === "glitch" ? 0 : h / 2, 1, h / 2);
  }
  ctx.globalAlpha = 1;
  const x0 = xOf(Math.max(0, R.pos - S.windowSec)), x1 = xOf(R.pos);
  ctx.fillStyle = "rgba(78,161,255,0.18)";
  ctx.fillRect(x0, 0, Math.max(1, x1 - x0), h);
  ctx.fillStyle = "#4ea1ff";
  ctx.fillRect(Math.round(x1) - 1, 0, 2, h);
}

function bindTimeline() {
  const canvas = $("timeline");
  const seekTo = (ev) => {
    const rect = canvas.getBoundingClientRect();
    seek(((ev.clientX - rect.left) / rect.width) * S.replay.duration);
  };
  canvas.addEventListener("pointerdown", (ev) => {
    if (!S.replay) return;
    canvas.setPointerCapture(ev.pointerId);
    seekTo(ev);
  });
  canvas.addEventListener("pointermove", (ev) => {
    if (S.replay && canvas.hasPointerCapture(ev.pointerId)) seekTo(ev);
  });
  $("event-log").addEventListener("click", (ev) => {
    const li = ev.target.closest("li.seekable");
    if (!li || !S.replay) return;
    setPlaying(false);
    seek(Number(li.dataset.t) + S.windowSec * 0.3); // event at 70% across the charts
  });
}

// ------------------------------------------------------------- library --

function setLibraryNote(text) {
  const note = $("lib-note");
  if (note) setText(note, text);
}

async function refreshLibrary() {
  if (S.libraryBusy) return;
  S.libraryBusy = true;
  try {
    const res = await fetch("/api/recordings");
    S.library = await res.json();
    renderLibrary();
    // Summaries are computed on demand, one file at a time, newest first.
    for (const f of S.library.files) {
      if (f.summary || f.recording) continue;
      const r = await fetch(`/api/recordings/summary?name=${encodeURIComponent(f.name)}`);
      const sum = await r.json();
      f.summary = r.ok ? sum : { error: sum.error || "unreadable" };
      renderLibrary();
    }
  } finally {
    S.libraryBusy = false;
  }
}

function healthCell(sum) {
  if (!sum) return '<span class="muted">checking…</span>';
  if (sum.error) return `<span class="bad">${escapeHtml(sum.error)}</span>`;
  const problems = healthItems(sum).filter(([, v]) => v).map(([k, v, cls]) => `<span class="${cls}">${v} ${k}</span>`);
  const enc = `${sum.live_encoders}/${sum.encoders.length} encoders`;
  return (problems.length ? problems.join(" · ") : '<span class="good-text">clean</span>') + ` <span class="muted">· ${enc}</span>`;
}

function renderLibrary() {
  const lib = S.library;
  setText($("lib-dir"), lib.dir);
  const rows = lib.files.map((f) => {
    const sum = f.summary;
    const name = escapeHtml(f.name);
    const q = encodeURIComponent(f.name);
    const playing = S.replay && S.replay.name === f.name;
    const actions = f.recording
      ? '<span class="pill pill-rec">recording now</span>'
      : `<button class="small" data-act="replay" data-name="${name}"${sum && sum.error ? " disabled" : ""}>${playing ? "Replaying" : "Replay"}</button>
         <a class="button small" href="/api/recordings/file?name=${q}" download>Download</a>
         <button class="small danger" data-act="delete" data-name="${name}">Delete</button>`;
    const ok = sum && !sum.error;
    return `<tr class="${playing ? "selected" : ""}"><td class="mono">${name}</td>
      <td>${ok && sum.start_str ? sum.start_str : new Date(f.mtime * 1000).toLocaleString()}</td>
      <td>${ok ? fmtDuration(sum.duration) : ""}</td><td>${ok ? sum.frames.toLocaleString() : ""}</td>
      <td>${fmtBytes(f.size)}</td><td>${f.recording ? "" : healthCell(sum)}</td><td class="actions">${actions}</td></tr>`;
  });
  $("lib-table").innerHTML = `<thead><tr><th>File</th><th>Recorded</th><th>Length</th><th>Frames</th><th>Size</th>
    <th>Health</th><th></th></tr></thead><tbody>${rows.join("") ||
    '<tr><td colspan="7" class="empty">No recordings yet. Press ● Record to make one.</td></tr>'}</tbody>
    <caption id="lib-note"></caption>`;
}

async function onLibraryClick(ev) {
  const btn = ev.target.closest("button[data-act]");
  if (!btn) return;
  const name = btn.dataset.name;
  if (btn.dataset.act === "replay") {
    await startReplay(name);
  } else if (btn.dataset.act === "delete") {
    if (!confirm(`Delete ${name}? This removes the file from disk.`)) return;
    const res = await post("/api/recordings/delete", { name });
    if (res.error) { alert(res.error); return; }
    if (S.replay && S.replay.name === name) exitReplay();
    refreshLibrary();
  }
}

// ------------------------------------------------------------ controls --

function setView(view) {
  S.view = view;
  for (const b of document.querySelectorAll(".tab")) b.classList.toggle("active", b.dataset.view === view);
  for (const v of ["encoders", "tactile", "recordings"]) $(`view-${v}`).hidden = v !== view;
  S.lastText = 0;
  if (view === "recordings") refreshLibrary();
}

function togglePause() {
  S.paused = !S.paused;
  if (S.paused) {
    S.heldStatus = S.status;
    S.held = { enc: S.live.enc.slice(), tac: { ...S.live.tac } };
    S.pausedAt = serverNow();
  }
  setText($("btn-pause"), S.paused ? "Resume (space)" : "Pause (space)");
  $("btn-pause").classList.toggle("active", S.paused);
  S.eventsDirty = true;
}

function toggleScale() {
  S.autoscale = !S.autoscale;
  updateLabels();
}

// Button texts, shortened in the half-screen layout.
function updateLabels() {
  const n = S.narrow;
  setText($("btn-scale"), `${n ? "" : "Scale: "}${S.autoscale ? "auto" : "fixed"} (a)`.replace(/^./, (c) => c.toUpperCase()));
  $("btn-scale").classList.toggle("active", S.autoscale);
  setText($("btn-reset"), n ? "Reset (r)" : "Reset stats (r)");
  setText($("btn-more-stats"), S.allStats ? "less" : "more");
  updateTareButton();
  document.body.classList.toggle("narrow", n);
  if (!n) setEventsOpen(false);
  S.lastText = 0;
}

function setEventsOpen(open) {
  S.eventsOpen = open;
  $("events").classList.toggle("open", open);
  if (open) hideToast();
}

function hideToast() {
  $("toast").hidden = true;
  clearTimeout(S.toastTimer);
}

// In the half-screen layout the events panel is a drawer, so new events also
// show for a few seconds in a strip under the header.
function toast(events) {
  if (!S.narrow || S.eventsOpen || S.replay || S.paused) return;
  const e = events[events.length - 1];
  const who = e.enc === null ? "" : `#${String(e.enc).padStart(2, "0")} `;
  const more = events.length > 1 ? ` <span class="muted">(+${events.length - 1} more)</span>` : "";
  const el = $("toast");
  el.innerHTML = `<span class="when">${e.wall}</span><span class="kind kind-${e.kind}">${e.kind}</span>` +
    `<span>${who}${escapeHtml(e.text)}${more}</span>`;
  el.hidden = false;
  clearTimeout(S.toastTimer);
  S.toastTimer = setTimeout(hideToast, TOAST_MS);
}

function tare() {
  const live = S.shown || S.live;
  S.tare = cards.map((_, id) => (live.enc[id] == null ? null : live.enc[id]));
  S.tacTare = {};
  for (const id in live.tac) S.tacTare[id] = { n1: live.tac[id][0], n2: live.tac[id][3] };
  updateTareButton();
}

function clearTare() {
  S.tare = null;
  S.tacTare = null;
  updateTareButton();
}

// In the half-screen layout Tare and Clear tare share one button, so the
// toolbar keeps its width when a tare is set.
function updateTareButton() {
  const merged = S.narrow && S.tare;
  setText($("btn-tare"), merged ? "Untare (Z)" : "Tare (z)");
  $("btn-tare").classList.toggle("active", !!merged);
  $("btn-untare").hidden = S.narrow;
}

function onTareButton() {
  if (S.narrow && S.tare) clearTare(); else tare();
}

async function resetStats() {
  await post("/api/reset");
  S.events = [];
  S.eventsDirty = true;
}

async function toggleRecord() {
  const on = !(S.status && S.status.recording);
  const res = await post("/api/record", { on });
  if (S.status) S.status.recording = res.recording;
}

function bindControls() {
  for (const b of document.querySelectorAll(".tab")) b.addEventListener("click", () => setView(b.dataset.view));
  $("window").addEventListener("change", (e) => { S.windowSec = Number(e.target.value); });
  $("btn-scale").addEventListener("click", toggleScale);
  $("btn-tare").addEventListener("click", onTareButton);
  $("btn-untare").addEventListener("click", clearTare);
  $("btn-pause").addEventListener("click", togglePause);
  $("btn-reset").addEventListener("click", resetStats);
  $("btn-record").addEventListener("click", toggleRecord);
  $("btn-more-stats").addEventListener("click", () => { S.allStats = !S.allStats; updateLabels(); });
  $("btn-events").addEventListener("click", () => setEventsOpen(!S.eventsOpen));
  $("events-close").addEventListener("click", () => setEventsOpen(false));
  $("toast").addEventListener("click", () => setEventsOpen(true));
  narrowQuery.addEventListener("change", (e) => { S.narrow = e.matches; updateLabels(); });
  $("focus-clear").addEventListener("click", () => { S.focus = []; renderFocusLegend(); });
  $("btn-unused").addEventListener("click", toggleUnused);
  $("lib-refresh").addEventListener("click", refreshLibrary);
  $("lib-table").addEventListener("click", onLibraryClick);
  $("btn-play").addEventListener("click", () => setPlaying(!S.replay.playing));
  $("btn-back").addEventListener("click", () => seek(S.replay.pos - 1));
  $("btn-fwd").addEventListener("click", () => seek(S.replay.pos + 1));
  $("btn-exit-replay").addEventListener("click", exitReplay);
  $("speed").addEventListener("change", (e) => { if (S.replay) S.replay.speed = Number(e.target.value); });
  bindTimeline();
  // A clicked button keeps focus, and the space bar would then press it a second time.
  document.addEventListener("click", (e) => { if (e.target.tagName === "BUTTON") e.target.blur(); });
  setInterval(() => { if (S.view === "recordings" && !S.libraryBusy) refreshLibrary(); }, 3000);
  document.addEventListener("keydown", (e) => {
    if (e.target.tagName === "SELECT" || e.metaKey || e.ctrlKey || e.altKey) return;
    const R = S.replay;
    const step = e.shiftKey ? 5 : 1;
    const actions = {
      "1": () => setView("encoders"),
      "2": () => setView("tactile"),
      "3": () => setView("recordings"),
      " ": R ? () => setPlaying(!R.playing) : togglePause,
      z: tare,
      Z: clearTare,
      a: toggleScale,
      u: toggleUnused,
      e: S.narrow ? () => setEventsOpen(!S.eventsOpen) : null,
      r: R ? null : resetStats,
      ArrowLeft: R ? () => seek(R.pos - step) : null,
      ArrowRight: R ? () => seek(R.pos + step) : null,
      Escape: () => {
        if (S.eventsOpen) setEventsOpen(false);
        else if (S.focus.length || !R) { S.focus = []; renderFocusLegend(); } else exitReplay();
      },
    };
    const action = actions[e.key];
    if (action) {
      e.preventDefault();
      action();
    }
  });
}

async function init() {
  S.cfg = await (await fetch("/api/config")).json();
  S.boot = S.cfg.boot;
  setText($("port"), S.cfg.port);
  for (let i = 0; i < S.cfg.encoder_count; i++) S.enc.push(new Ring());
  buildEncoderGrid();
  buildTactile();
  bindControls();
  updateLabels();
  connect();
  requestAnimationFrame(frame);
}

init();
