# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""
Shared core of the DexUMI Hand Monitor: UMI frame decoding, the serial reader
thread, link-health tracking (dropped frames, board resets, encoder glitches)
and port auto-detection. Both the browser and the terminal front ends use it.
"""

import math
import os
import struct
import sys
import threading
import time
from collections import deque

try:
    import serial
except ImportError:  # fall back to the pyserial copy bundled in vendor/
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor"))
    try:
        import serial
    except ImportError:
        sys.exit("pyserial not found and the bundled copy in vendor/ is missing.")
from serial.tools import list_ports

# ---------------------------------------------------------------- protocol --

SYNC = b"\xa5\x5a"
FRAME_OVERHEAD = 12  # sync(2) + header(8) + crc(2)
MAX_PAYLOAD = 65535

SENSOR_TYPE_ENCODER = 0x01
SENSOR_TYPE_TACTILE = 0x02
TACTILE_DATA_SIZE = 80
TACTILE_STRUCT = struct.Struct("<13I I I H I I H I I")
RAW_CHANNELS = 13

SOURCE_NAMES = {0x1: "UMI Gripper", 0x2: "DexUMI"}

# boards/dexumi_palm_common.h
ENCODER_COUNT = 15
FINGERS = ["Thumb", "Index", "Middle", "Ring", "Pinky"]
JOINTS = ["base", "mid", "tip"]
ENCODER_TO_TACTILE = [-1, -1, 33, 30, 4, 34, -1, 7, 35, -1, 10, 36, -1, 13, 37]

# Tactile IDs live in their own namespace (docs/orange_protocol.md §4.1).
TACTILE_LOCATIONS = {
    33: "Thumb tip",
    30: "Palm",
    4: "Index pad",
    34: "Index tip",
    7: "Middle pad",
    35: "Middle tip",
    10: "Ring pad",
    36: "Ring tip",
    13: "Pinky pad",
    37: "Pinky tip",
}
TACTILE_ORDER = [t for t in ENCODER_TO_TACTILE if t >= 0]

PICO_VID = 0x2E8A


def _build_crc16_table():
    table = []
    for byte in range(256):
        crc = byte << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
        table.append(crc)
    return table


CRC16_TABLE = _build_crc16_table()
assert CRC16_TABLE[1] == 0x1021 and CRC16_TABLE[255] == 0x1EF0


def crc16(data) -> int:
    crc = 0
    for byte in data:
        crc = ((crc << 8) ^ CRC16_TABLE[((crc >> 8) ^ byte) & 0xFF]) & 0xFFFF
    return crc


def parse_tactile(data):
    fields = TACTILE_STRUCT.unpack(data)
    return {
        "raw": fields[0:RAW_CHANNELS],
        "n1": fields[13],
        "t1": fields[14],
        "a1": fields[15],
        "n2": fields[16],
        "t2": fields[17],
        "a2": fields[18],
        "p1": fields[19],
        "p2": fields[20],
    }


def parse_payload(payload):
    """Return (encoders, tactiles) for one frame's TLV chain."""
    encoders = {}
    tactiles = {}
    offset = 0
    end = len(payload)
    while offset + 4 <= end:
        sensor_type = payload[offset]
        sensor_id = payload[offset + 1]
        length = struct.unpack_from("<H", payload, offset + 2)[0]
        offset += 4
        if offset + length > end:
            break
        if sensor_type == SENSOR_TYPE_ENCODER and length == 4:
            encoders[sensor_id] = struct.unpack_from("<f", payload, offset)[0]
        elif sensor_type == SENSOR_TYPE_TACTILE and length == TACTILE_DATA_SIZE:
            tactiles[sensor_id] = parse_tactile(bytes(payload[offset : offset + length]))
        offset += length
    return encoders, tactiles


# ------------------------------------------------------------------- state --


class TactileChannel:
    """Rolling view of one tactile sensor."""

    def __init__(self, sensor_id):
        self.id = sensor_id
        self.location = TACTILE_LOCATIONS.get(sensor_id, f"Unknown #{sensor_id}")
        self.latest = None
        self.last_seen = 0.0
        self.updates = deque(maxlen=120)
        self.raw_min = [math.inf] * RAW_CHANNELS
        self.raw_max = [-math.inf] * RAW_CHANNELS
        self.n1_max = 0
        self.n2_max = 0

    def update(self, sample, now):
        self.latest = sample
        self.last_seen = now
        self.updates.append(now)
        for ch, value in enumerate(sample["raw"]):
            if value < self.raw_min[ch]:
                self.raw_min[ch] = value
            if value > self.raw_max[ch]:
                self.raw_max[ch] = value
        self.n1_max = max(self.n1_max, sample["n1"])
        self.n2_max = max(self.n2_max, sample["n2"])

    def hz(self):
        if len(self.updates) < 2:
            return 0.0
        span = self.updates[-1] - self.updates[0]
        return (len(self.updates) - 1) / span if span > 0 else 0.0

    def reset(self):
        self.raw_min = [math.inf] * RAW_CHANNELS
        self.raw_max = [-math.inf] * RAW_CHANNELS
        self.n1_max = 0
        self.n2_max = 0
        self.updates.clear()


class MonitorState:
    """Latest decoded values plus link-health counters, shared with the UI."""

    RATE_WINDOW = 240  # frames (~2 s at 120 Hz)
    STALE_AFTER = 0.5  # seconds without a valid reading
    PERIOD_WARMUP = 20  # board_ts deltas needed before gaps are judged
    GAP_FACTOR = 1.5  # a delta this many periods long means frames went missing
    GLITCH_MAX_DT_MS = 100  # beyond this the joint may really have moved that far
    GARBAGE_DEG = 3600.0  # readings beyond this are corrupt, not angles
    SETTLE_S = 1.0  # after a reconnect or board restart, glitches are not judged
    SETTLE_FRAMES = 5  # readings an encoder gets to settle after it (re)appears
    def __init__(self, count=ENCODER_COUNT, glitch_rate=2000.0):
        self.lock = threading.Lock()
        self.count = count
        self.glitch_rate = glitch_rate
        self.values = [None] * count
        self.last_valid = [0.0] * count
        self.vmin = [math.inf] * count
        self.vmax = [-math.inf] * count
        self.history = [deque(maxlen=self.RATE_WINDOW) for _ in range(count)]
        self._prev_good = [None] * count  # (value, board_ts_ms) of the last valid reading
        self.glitches = [0] * count
        self._in_glitch = [False] * count
        self._settle_left = [0] * count
        self._settle_until = 0.0
        self.frame_values = [None] * count  # usable angle per encoder in the latest frame
        self.last_glitch = None
        self._ts_deltas = deque(maxlen=self.RATE_WINDOW)
        self._prev_ts = None
        self._offline_since = None
        self.period_ms = None
        self.dropped = 0
        self.gaps = 0
        self.longest_gap_ms = 0
        self.board_resets = 0
        self.events = deque(maxlen=1000)  # (seq, host monotonic time, kind, encoder or None, text)
        self.event_seq = 0
        self.tactile = {tid: TactileChannel(tid) for tid in TACTILE_ORDER}
        self.tactile_order = list(TACTILE_ORDER)
        self.frames = 0
        self.crc_errors = 0
        self.resyncs = 0
        self.version = None
        self.source = None
        self.board_ts_ms = 0
        self.last_frame_time = 0.0
        self.frame_dt = 0.0
        self._fps_window = deque(maxlen=self.RATE_WINDOW)
        self.error = None
        self.port = None  # serial port in use; None until the board has been found
        self.reconnects = 0
        self.last_drop = None

    def on_frame(self, version, source, ts_ms, encoders, tactiles, now=None):
        """`now` is the host receive time; recordings being replayed pass their own."""
        if now is None:
            now = time.monotonic()
        with self.lock:
            self.frames += 1
            self.version = version
            self.source = source
            self.board_ts_ms = ts_ms
            if self.last_frame_time:
                self.frame_dt = now - self.last_frame_time
            self.last_frame_time = now
            self._fps_window.append(now)
            self._track_timing(ts_ms, now)

            for idx in range(self.count):
                value = encoders.get(idx)
                self.frame_values[idx] = None
                if value is None:
                    continue
                good = self._check_encoder(idx, value, ts_ms, now)
                self.history[idx].append(good)
                if good:
                    self.frame_values[idx] = round(value, 3)
                    self.values[idx] = value
                    self.last_valid[idx] = now
                    if value < self.vmin[idx]:
                        self.vmin[idx] = value
                    if value > self.vmax[idx]:
                        self.vmax[idx] = value

            for sensor_id, sample in tactiles.items():
                channel = self.tactile.get(sensor_id)
                if channel is None:
                    # Firmware may grow new sensor IDs; show them anyway.
                    channel = TactileChannel(sensor_id)
                    self.tactile[sensor_id] = channel
                    self.tactile_order.append(sensor_id)
                channel.update(sample, now)

    def mark_offline(self, now=None):
        with self.lock:
            if self._offline_since is None:
                self._offline_since = time.monotonic() if now is None else now
                self._event(self._offline_since, "link", None, "USB link lost")

    def _rebaseline(self, now):
        """Positions after an outage may come from a rebooted or different hand,
        so they are not comparable with the ones before it."""
        self._prev_good = [None] * self.count
        self._in_glitch = [False] * self.count
        self._settle_until = now + self.SETTLE_S

    def _track_timing(self, ts_ms, now):
        """Count frames missing from the board_ts sequence. The nominal period is
        learned rather than assumed: dead chains stretch the cycle past 8.33 ms."""
        prev, self._prev_ts = self._prev_ts, ts_ms
        offline_since, self._offline_since = self._offline_since, None
        if offline_since is not None:
            outage_ms = (now - offline_since) * 1000
            self._event(now, "link", None, f"link restored after {outage_ms / 1000:.1f} s")
            self._rebaseline(now)
        if prev is None:
            return
        delta = ts_ms - prev
        # A board that stayed powered through the outage resumes at prev + outage;
        # any other timestamp means it restarted or a different hand was plugged in.
        changed = delta < 0 or (
            offline_since is not None and abs(delta - outage_ms) > max(1000.0, 0.2 * outage_ms)
        )
        if changed:
            self.board_resets += 1
            self._rebaseline(now)
            self._event(now, "reset", None, f"board restarted or replaced (uptime {ts_ms / 1000:.1f} s)")
            return
        if self.period_ms and delta > self.GAP_FACTOR * self.period_ms:
            missed = max(1, round(delta / self.period_ms) - 1)
            self.gaps += 1
            self.dropped += missed
            self.longest_gap_ms = max(self.longest_gap_ms, delta)
            self._event(now, "drop", None, f"{missed} frame(s) missing ({delta} ms gap)")
        self._ts_deltas.append(delta)
        if len(self._ts_deltas) >= self.PERIOD_WARMUP:
            ordered = sorted(self._ts_deltas)
            cutoff = self.GAP_FACTOR * ordered[len(ordered) // 2]
            normal = [d for d in ordered if d <= cutoff]
            self.period_ms = sum(normal) / len(normal)

    def _event(self, now, kind, encoder, text):
        self.event_seq += 1
        self.events.append((self.event_seq, now, kind, encoder, text))

    def events_since(self, seq):
        with self.lock:
            return [e for e in self.events if e[0] > seq]

    def _check_encoder(self, idx, value, ts_ms, now):
        """Return whether value is a usable angle, counting glitches on the way.
        A burst of consecutive bad readings (a spike out and back) is one glitch."""
        if math.isnan(value):
            self._prev_good[idx] = None
            return False
        if value == 0.0 and self._prev_good[idx] is None:
            # Encoders send exactly 0.0 for a few seconds after power-up, until they
            # have initialised; that is not a position. A 0.0 straight after a real
            # reading is still checked like any other value.
            return False
        problem = None
        usable = math.isfinite(value) and abs(value) <= self.GARBAGE_DEG
        settling = now < self._settle_until or self._settle_left[idx] > 0
        if not usable:
            if not settling:
                problem = f"bad value {value:g}"
        else:
            prev = self._prev_good[idx]
            self._prev_good[idx] = (value, ts_ms)
            dt = ts_ms - prev[1] if prev is not None else None
            if dt is None or not 0 < dt <= self.GLITCH_MAX_DT_MS:
                self._settle_left[idx] = self.SETTLE_FRAMES
            elif self._settle_left[idx] > 0:
                self._settle_left[idx] -= 1
            elif not settling:
                step = (value - prev[0] + 180.0) % 360.0 - 180.0
                if abs(step) * 1000.0 / dt > self.glitch_rate:
                    problem = f"jump {step:+.1f}° in {dt}ms"
        if problem:
            if not self._in_glitch[idx]:
                self.glitches[idx] += 1
                self.last_glitch = (idx, problem, time.strftime("%H:%M:%S"))
                self._event(now, "glitch", idx, problem)
            self._in_glitch[idx] = True
        else:
            self._in_glitch[idx] = False
        return usable

    def fps(self):
        if len(self._fps_window) < 2:
            return 0.0
        span = self._fps_window[-1] - self._fps_window[0]
        return (len(self._fps_window) - 1) / span if span > 0 else 0.0

    def reset_stats(self):
        with self.lock:
            self.vmin = [math.inf] * self.count
            self.vmax = [-math.inf] * self.count
            self.frames = 0
            self.crc_errors = 0
            self.resyncs = 0
            self.glitches = [0] * self.count
            self._in_glitch = [False] * self.count
            self.last_glitch = None
            self.events.clear()
            self.dropped = 0
            self.gaps = 0
            self.longest_gap_ms = 0
            self.board_resets = 0
            for hist in self.history:
                hist.clear()
            for channel in self.tactile.values():
                channel.reset()
            self._fps_window.clear()

    def snapshot(self):
        now = time.monotonic()
        with self.lock:
            encoder_rows = []
            for idx in range(self.count):
                hist = self.history[idx]
                age = now - self.last_valid[idx] if self.last_valid[idx] else None
                encoder_rows.append(
                    {
                        "value": self.values[idx],
                        "min": self.vmin[idx] if self.vmin[idx] != math.inf else None,
                        "max": self.vmax[idx] if self.vmax[idx] != -math.inf else None,
                        "good": (sum(hist) / len(hist)) if hist else None,
                        "stale": age is None or age > self.STALE_AFTER,
                        "glitches": self.glitches[idx],
                    }
                )

            tactile_rows = []
            for sensor_id in self.tactile_order:
                channel = self.tactile[sensor_id]
                age = now - channel.last_seen if channel.last_seen else None
                tactile_rows.append(
                    {
                        "id": sensor_id,
                        "location": channel.location,
                        "sample": channel.latest,
                        "hz": channel.hz(),
                        "stale": age is None or age > self.STALE_AFTER,
                        "raw_min": list(channel.raw_min),
                        "raw_max": list(channel.raw_max),
                        "n1_max": channel.n1_max,
                        "n2_max": channel.n2_max,
                    }
                )

            return {
                "encoders": encoder_rows,
                "tactiles": tactile_rows,
                "frames": self.frames,
                "crc_errors": self.crc_errors,
                "resyncs": self.resyncs,
                "version": self.version,
                "source": self.source,
                "board_ts_ms": self.board_ts_ms,
                "fps": self.fps(),
                "frame_dt": self.frame_dt,
                "link_age": now - self.last_frame_time if self.last_frame_time else None,
                "error": self.error,
                "port": self.port,
                "reconnects": self.reconnects,
                "last_drop": self.last_drop,
                "period_ms": self.period_ms,
                "dropped": self.dropped,
                "gaps": self.gaps,
                "longest_gap_ms": self.longest_gap_ms,
                "board_resets": self.board_resets,
                "glitches": sum(self.glitches),
                "last_glitch": self.last_glitch,
            }


# ------------------------------------------------------------------ reader --


class Reader(threading.Thread):
    """Pulls bytes off the serial port and feeds decoded frames to the state."""

    daemon = True

    WAITING = "waiting for the board - plug it in"

    def __init__(self, port, baudrate, state, csv_file=None):
        """port=None: find the board by itself, waiting for it to be plugged in."""
        super().__init__(name="umi-reader")
        self.port = port
        state.port = port
        if port is None:
            state.error = self.WAITING
        self.baudrate = baudrate
        self.state = state
        self.csv_file = csv_file
        self.csv_rows = 0
        self._csv_lock = threading.Lock()
        self._stop_event = threading.Event()

    def stop(self):
        self._stop_event.set()

    def set_csv(self, csv_file):
        """Swap the recording target (None stops recording); returns the old file."""
        with self._csv_lock:
            old, self.csv_file = self.csv_file, csv_file
            self.csv_rows = 0
        return old

    def run(self):
        """Reconnect forever: the board re-enumerates whenever it resets, which
        makes the device node vanish and reappear under the host."""
        first = True
        misses = 0
        while not self._stop_event.is_set():
            if self.port is None:
                found, _ = autodetect_port(self.baudrate, seconds=0.4, any_port=False)
                if not found:
                    self._stop_event.wait(0.5)
                    continue
                self.port = self.state.port = found
            try:
                with serial.Serial(self.port, self.baudrate, timeout=0.05) as ser:
                    if not first:
                        self.state.reconnects += 1
                    first = False
                    misses = 0
                    self.state.error = None
                    self._pump(ser)
            except (serial.SerialException, OSError) as exc:
                self.state.mark_offline()
                self.state.last_drop = time.strftime("%H:%M:%S")
                self.state.error = f"link lost ({exc.__class__.__name__}), reconnecting..."
                misses += 1
                # After a while, the board may have come back on a different node.
                if misses % 10 == 0:
                    found, _ = autodetect_port(self.baudrate, seconds=0.4)
                    if found:
                        self.port = self.state.port = found
            self._stop_event.wait(0.25)

    def _pump(self, ser):
        buf = bytearray()
        while not self._stop_event.is_set():
            chunk = ser.read(max(1, ser.in_waiting))
            if chunk:
                buf.extend(chunk)
            self._drain(buf)
            if len(buf) > 1 << 20:
                del buf[:-4096]

    def _drain(self, buf):
        while True:
            idx = buf.find(SYNC)
            if idx < 0:
                # Keep a trailing 0xA5 in case the sync word straddles reads.
                del buf[: max(0, len(buf) - 1)]
                return
            if idx:
                del buf[:idx]
                self.state.resyncs += 1
            if len(buf) < FRAME_OVERHEAD:
                return
            payload_len = struct.unpack_from("<H", buf, 8)[0]
            if payload_len > MAX_PAYLOAD:
                del buf[:2]
                self.state.resyncs += 1
                continue
            total = FRAME_OVERHEAD + payload_len
            if len(buf) < total:
                return
            crc_rx = struct.unpack_from("<H", buf, 10 + payload_len)[0]
            if crc_rx != crc16(memoryview(buf)[2 : 10 + payload_len]):
                self.state.crc_errors += 1
                del buf[:2]
                continue
            version = buf[2]
            source = buf[3]
            ts_ms = struct.unpack_from("<I", buf, 4)[0]
            encoders, tactiles = parse_payload(memoryview(buf)[10 : 10 + payload_len])
            del buf[:total]
            self.state.on_frame(version, source, ts_ms, encoders, tactiles)
            self._log_csv(ts_ms, encoders, tactiles)

    def _log_csv(self, ts_ms, encoders, tactiles):
        if not self.csv_file or not encoders:
            return
        cells = []
        for idx in range(self.state.count):
            value = encoders.get(idx)
            cells.append("" if value is None or math.isnan(value) else f"{value:.4f}")
        for sensor_id in TACTILE_ORDER:
            sample = tactiles.get(sensor_id)
            if sample is None:
                cells.extend([""] * 8)
            else:
                cells.extend(
                    str(sample[key]) for key in ("n1", "t1", "a1", "n2", "t2", "a2", "p1", "p2")
                )
        with self._csv_lock:
            if self.csv_file:
                self.csv_file.write(f"{time.time():.6f},{ts_ms}," + ",".join(cells) + "\n")
                self.csv_rows += 1


def open_csv(path):
    """Open a recording for appending, writing the header if it is new."""
    csv_file = open(path, "a", buffering=1)
    if csv_file.tell() == 0:
        csv_file.write(csv_header())
    return csv_file


def csv_header():
    cols = [f"enc{i}" for i in range(ENCODER_COUNT)]
    for sensor_id in TACTILE_ORDER:
        cols.extend(
            f"tac{sensor_id}_{key}" for key in ("n1", "t1", "a1", "n2", "t2", "a2", "p1", "p2")
        )
    return "host_time,board_ts_ms," + ",".join(cols) + "\n"


# -------------------------------------------------------------- port picker --


def candidate_ports(any_port=True):
    """Ports that look like the palm board, else (if any_port) every port."""
    ports = [p for p in list_ports.comports() if p.vid == PICO_VID]
    return ports if ports or not any_port else list(list_ports.comports())


def probe_for_frames(device, baudrate, seconds=1.0):
    """True if a CRC-valid UMI frame shows up on this port. CDC 0 is the debug
    console and only emits plain text, so this picks out the data interface."""
    try:
        with serial.Serial(device, baudrate, timeout=0.1) as ser:
            buf = bytearray()
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline:
                buf.extend(ser.read(max(1, ser.in_waiting)))
                start = 0
                while True:
                    idx = buf.find(SYNC, start)
                    if idx < 0 or len(buf) - idx < FRAME_OVERHEAD:
                        break
                    payload_len = struct.unpack_from("<H", buf, idx + 8)[0]
                    if len(buf) - idx < FRAME_OVERHEAD + payload_len:
                        break
                    crc_rx = struct.unpack_from("<H", buf, idx + 10 + payload_len)[0]
                    if crc_rx == crc16(memoryview(buf)[idx + 2 : idx + 10 + payload_len]):
                        return True
                    start = idx + 2
    except serial.SerialException:
        return False
    return False


def autodetect_port(baudrate, seconds=1.0, any_port=True):
    ports = candidate_ports(any_port)
    if not ports:
        return None, "no serial ports found - is the board plugged in?"
    # Prefer the higher interface number: CDC 1 carries the UMI stream.
    for port in sorted(ports, key=lambda p: p.device, reverse=True):
        if probe_for_frames(port.device, baudrate, seconds):
            return port.device, None
    listing = ", ".join(p.device for p in ports)
    return None, f"no UMI frames seen on: {listing}"
