#!/bin/bash
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

# Launch the DexUMI Hand Monitor.
#
# No installation required: pyserial is bundled in vendor/ and the script falls
# back to it automatically when it is not already installed.
set -euo pipefail

cd "$(dirname "$0")"

if command -v python3 >/dev/null 2>&1; then
    PYTHON=python3
elif command -v python >/dev/null 2>&1; then
    PYTHON=python
else
    echo "Error: python3 was not found." >&2
    echo "On macOS, install Apple's command line tools with: xcode-select --install" >&2
    exit 1
fi

# macOS ships a python3 stub that only prompts to install the command line
# tools; catch that here rather than failing with a confusing error later.
if ! "$PYTHON" -c "import sys" >/dev/null 2>&1; then
    echo "Error: '$PYTHON' is not usable yet." >&2
    echo "Run 'xcode-select --install', let it finish, then try again." >&2
    exit 1
fi

exec "$PYTHON" hand_monitor.py "$@"
