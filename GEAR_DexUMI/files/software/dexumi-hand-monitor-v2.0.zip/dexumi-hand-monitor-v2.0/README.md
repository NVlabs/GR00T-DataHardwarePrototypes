# DexUMI Hand Monitor v2

Live dashboard for the DexUMI exo hand. It reads the palm board over USB and
shows all 15 joint encoders and 10 tactile sensors as scrolling graphs in your
web browser, along with link health: dropped frames, board resets and encoder
glitches. The original terminal dashboard is still available with `--tui`.

The browser page is served by the tool itself on this computer
(`http://127.0.0.1:8765/`). Nothing is sent over the network, and nothing needs
to be installed: the graphs are plain HTML and JavaScript, and pyserial is
bundled in `vendor/`.

## Quick start

Unzip this folder anywhere and run the launcher for your system. It opens the
dashboard in your default browser and finds the board's serial port by itself.
The hand does not need to be plugged in first: until it is, the dashboard shows
`WAITING FOR BOARD` and picks the board up within about a second of you plugging
it in. Leave the terminal window open while you use it; press `Ctrl+C` there to
quit.

### macOS

```bash
cd dexumi-hand-monitor-v2.0
./run.sh
```

Needs `python3`, which most Macs used for development already have. If it is
missing, run `xcode-select --install` and let it finish. If you get
`permission denied`, see the note under Linux.

### Linux

```bash
cd dexumi-hand-monitor-v2.0
./run.sh
```

If that says `permission denied`, the launcher lost its "executable" flag on the
way to you. The zip stores it, but copying the folder through a FAT/exFAT USB
stick, a cloud drive or a chat app, or unpacking it with some extractors, drops
it. Either start it through bash, which works regardless:

```bash
bash run.sh
```

or restore the flag once with `chmod +x run.sh`, after which `./run.sh` works.

Serial devices belong to the `dialout` group, so grant yourself access once and
log back in, otherwise opening the port fails with a permission error:

```bash
sudo usermod -aG dialout $USER
```

The board appears as `/dev/ttyACM0` and `/dev/ttyACM1` rather than `/dev/cu.*`,
which the auto-detection handles on its own.

### Windows

```bat
cd dexumi-hand-monitor-v2.0
run.bat
```

The board appears as two `COM` ports. The browser view needs nothing extra;
only the terminal view (`--tui`) needs `pip install windows-curses`.

## Usage

Examples use `./run.sh`; on Windows substitute `run.bat`, which takes the same
options.

```bash
./run.sh                          # auto-detect the board, open the browser dashboard
./run.sh --tui                    # terminal dashboard instead
./run.sh --list                   # list serial ports
./run.sh -p /dev/cu.usbmodem2104  # choose the port yourself
./run.sh --csv session1.csv       # record from the start
./run.sh --no-browser             # don't open a tab (visit the printed address yourself)
./run.sh --http-port 9000         # use another local port if 8765 is taken
./run.sh --glitch-rate 3000       # tolerate faster joint motion before flagging a glitch
```

The board exposes two USB serial ports. The first is a debug console and the
second carries the sensor data, so the tool probes them and picks whichever one
produces valid data frames. Use `-p` only if that ever picks wrong.

## The browser dashboard

**Header.** The pill shows `LIVE`, `RECONNECTING` (board restarting, recovers by
itself), `NO DATA`, or `MONITOR STOPPED` (the terminal running the tool was
closed). Next to it: frame rate, frame period, frames received, dropped frames,
longest gap, board resets, glitches, CRC errors, resyncs, USB reconnects, live
tactile sensors and the board's uptime.

**Encoders view.** One card per encoder, laid out by finger (rows) and joint
(columns). Each card shows the angle, a scrolling trace, the minimum…maximum
(range) seen, the share of good readings, a red badge with its glitch count, and
the tactile sensor it carries. A greyed-out card is an encoder that is not
responding. While an encoder sends no valid angle (disconnected, or still
initialising after power-up) its value reads **NaN** in red and its trace is
shaded red and labelled NaN for that stretch. Click cards to overlay them in the large chart at the top; click a
name in its legend to remove it.

Markers on the traces: a **red line** is a glitch on that encoder, a **dashed
amber line** is a gap of dropped frames, a **dashed purple line** is a board
restart or a different hand being plugged in, and a **dashed grey line** is the
USB link being lost or restored. A trace also breaks where data is missing.

**Tactile view.** A table of every sensor's latest normal force, tangential
force and direction for both groups, proximity readings, maxima and update rate,
plus a trace per sensor of normal 1, normal 2 and tangential 1. Only the five
fingertip sensors are shown; the palm and finger-pad sensors (30, 4, 7, 10, 13),
which current hands do not carry, are hidden until you press **Show unused
sensors** (`u`). The choice is remembered by the browser.

**Recordings view.** Every file in `recordings/`, newest first, with when it was
recorded, its length, frame count, size and a health line: dropped frames, board
restarts, USB outages and glitches found in it, and how many encoders were
working. Files are checked with the same detection as the live view, so a
recording shows exactly what the live dashboard would have flagged. Each row has
**Replay**, **Download** and **Delete** (the file being recorded cannot be
deleted).

Angles and tactile values update on every screen refresh. Browsers draw at the
display's refresh rate (usually 60 Hz, 120 Hz on ProMotion screens), so at
120 Hz data you see every frame or every other frame; the traces always contain
every frame.

**Events.** The side panel lists every glitch, dropped-frame gap, board reset
and USB link loss/restore with its time.

**Half-screen layout.** In a window narrower than 1100 px the dashboard
switches to a compact layout by itself:
- The header shows only fps, dropped frames, glitches and reconnects; **more**
  shows the rest.
- Events move into a drawer opened with **Events (e)**. New events flash for a
  few seconds in a strip under the header; click the strip to open the drawer.
- Buttons get shorter labels (`Auto (a)`, `Reset (r)`), and Tare and Clear
  tare share one button: while a tare is set it reads **Untare (Z)**.
- Cards and charts are smaller, and the min…max line drops the range figure.
- The tactile table keeps only the pressures and directions.

### Controls

Each button shows its key in parentheses.

| Control | Key | Action |
| --- | --- | --- |
| Encoders / Tactile / Recordings | `1` `2` `3` | switch view |
| Show unused sensors | `u` | show or hide the palm and pad tactile sensors |
| Window | | how much history the traces show (5-60 s) |
| Scale | `a` | traces zoomed to what is on screen (default, button highlighted), or fixed 0-360° |
| Tare | `z` | show angles (and tactile normal forces) as deltas from now |
| Clear tare | `Z` | back to absolute values |
| Pause | `space` | freeze the display; data and recording continue underneath |
| Reset stats | `r` | clear min/max, error counters, dropped frames, glitches and events |
| Record | | start/stop recording to `recordings/dexumi-<date>-<time>.csv` |
| Events | `e` | open or close the events drawer (half-screen layout) |
| | `Esc` | close the events drawer, clear the large chart, or leave a replay |

Reloading the page keeps the last minute of traces, since the tool buffers them.

### Replaying a recording

**Replay** in the Recordings view loads a file into the Encoders and Tactile
views in place of live data (a blue `REPLAY` pill names the file; the live
connection keeps running, and you can still record). The header shows the whole
recording's statistics, the cards show each encoder's range, good share and
glitches over the recording, and the values are those at the playhead.

A transport bar appears under the toolbar. Its timeline shows the whole
recording, with glitches as red ticks along the top and dropped frames, restarts
and outages along the bottom; the shaded band is what the charts show, ending at
the playhead. Click or drag on it to move.

| Control | Key | Action |
| --- | --- | --- |
| Play / Pause | `space` | play or stop (playing again at the end starts over) |
| Speed | | 0.1× to 4× |
| −1 s / +1 s | `←` `→` | step back or forward (`Shift` for 5 s) |
| Exit replay | `Esc` | back to live data (`Esc` first clears the large chart if one is open) |

The Events panel lists the recording's events up to the playhead; click one to
jump there. Window, Scale, Tare and the large chart work as they do live.

## What the health numbers mean

- **period** — the board's frame interval, learned from its own timestamps. It
  is 8.33 ms (120 Hz) with every encoder connected and stretches to about 9.5 ms
  when encoders are missing, because the board waits for the absent ones.
- **dropped** — frames the board numbered but this computer never received,
  found as holes in the board's timestamp sequence. A USB disconnect during
  which the board kept running counts as dropped frames; a board restart does
  not, since nothing was being measured. A slow computer does not cause drops:
  the data is buffered and arrives late instead.
- **resets** — how many times the board restarted or a different hand was
  plugged in, recognised by its clock not continuing where it left off.
- **glitches** — encoder readings that jump faster than a hand can move (over
  2000°/s by default, about 19° between frames; change it with
  `--glitch-rate`), or that are not valid angles at all. A spike out and
  straight back counts as one glitch. Passing through 0°/360° is not a jump.
  Readings are never compared across an unplug/replug or board restart, so
  swapping hands while the tool runs does not count glitches; for the first
  second after the hand comes back, and for an encoder's first few readings
  after it reappears, jumps are ignored while the new positions settle.
  Encoders report exactly 0.0° for a few seconds after power-up while they
  initialise; those readings are treated as "not ready yet" (no glitch, no
  effect on min/max, a gap in the trace), so the jump to the real angle is not
  a glitch either. A 0.0 straight after real readings is still checked. A
  climbing count on one encoder points at a noisy connection or a magnet
  problem on that joint.

An encoder that is not responding is sent as NaN by the firmware. Because each
finger is one daisy-chained link, a whole finger going dark at once points at
that link's cable or connector rather than individual encoders.

Tactile sensors use their own ID numbering (4, 7, 10, 13, 30, 33-37) that does
not match encoder numbers, so they are labelled by location. A direction shown
as `—` is the sensor sending 65535 (0xFFFF): there is no tangential force, so
there is no direction to report. That is normal when the fingertip is not being
pressed. Recordings keep the raw 65535.

## Recording

Recordings (the Record button, or `--csv FILE`) get one row per frame, about
105-120 rows per second:

- `host_time` — wall clock time on this computer
- `board_ts_ms` — the board's own uptime in milliseconds
- `enc0`…`enc14` — joint angles in degrees, blank when an encoder is not responding
- `tac<id>_n1,_t1,_a1,_n2,_t2,_a2,_p1,_p2` — per sensor: normal force, tangential
  force and direction for both groups, then the two proximity readings

**Important:** `board_ts_ms` counts from the board's power-on, so it resets to
zero whenever the board restarts. Align your data on `host_time` and treat any
backwards jump in `board_ts_ms` as a restart boundary.

## Terminal dashboard (`--tui`)

The v1 terminal view, for when no browser is handy. Use a window at least 125
columns wide.

| Key | Action |
| --- | --- |
| `1` `2` `3` `4` | encoders / tactile / both (default) / raw channels of one sensor |
| `←` `→` | choose the sensor shown in the raw view |
| `z` / `Z` | tare / clear the tare |
| `r` | reset min, max, the error counters, dropped frames and glitches |
| `a` | switch encoder bars between a fixed 0-360° scale and each encoder's observed range |
| `space` | freeze the display (recording continues) |
| `q` | quit |

## Troubleshooting

**Stuck on `WAITING FOR BOARD`** — the tool has not seen a palm board on any
port. Check the cable, then run `./run.sh --list` in another terminal: the board
appears as two entries with ID `2E8A:0009`. If it is listed under a different
ID, pass its port with `-p`; the tool then keeps retrying that port until the
board answers.

**`RECONNECTING` and a growing reconnect count** — the board is restarting or
was unplugged. The tool recovers by itself within about a second of the hand
being back, so you do not need to restart it, and you can swap hands this way.
Frequent restarts, especially when you move the fingers or cables, indicate a
power or connector fault in the hand rather than a problem with this tool.

**The browser shows `MONITOR STOPPED`** — the tool is no longer running. Start
it again; the page reconnects on its own.

**The browser did not open** — visit the address printed in the terminal.

## Contents

```
run.sh            launcher for macOS and Linux
run.bat           launcher for Windows
hand_monitor.py   entry point: finds the board, starts the chosen view
umi_core.py       frame decoding, serial reader, dropped-frame and glitch detection
web.py            local web server for the browser dashboard
recording_library.py  recordings library: lists, checks and loads recordings for replay
web/              the dashboard page (HTML, CSS, JavaScript)
tui.py            terminal dashboard
vendor/serial/    bundled pyserial, BSD-3-Clause, unmodified
recordings/       created when you first press Record
```
