# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""
Recordings library: lists the CSV files in recordings/, and re-runs a file
through the same MonitorState as the live view so a replay shows the same
glitches, dropped frames and resets the live dashboard would have.
"""

import csv
import math
import os
import threading
import time
from collections import OrderedDict, deque

from umi_core import ENCODER_COUNT, MonitorState

TACTILE_KEYS = ("n1", "t1", "a1", "n2", "t2", "a2", "p1", "p2")
# A host-side pause this long, with the board clock jumping too, was a USB outage.
OUTAGE_S = 0.5
FULL_CACHE_SIZE = 2


class RecordingError(Exception):
    pass


def safe_path(directory, name):
    """Resolve a file name from the browser to a CSV inside `directory`."""
    if not name or os.path.basename(name) != name or not name.endswith(".csv"):
        raise RecordingError("invalid recording name")
    path = os.path.join(directory, name)
    if not os.path.isfile(path):
        raise RecordingError(f"{name} does not exist")
    return path


def _round(value):
    return round(value, 2) if value is not None and math.isfinite(value) else None


def analyze(path, glitch_rate):
    """Replay a recording through the detectors. Returns (summary, data)."""
    state = MonitorState(glitch_rate=glitch_rate)
    state.events = deque()  # keep every event, not just the latest 1000
    times = []
    enc = [[] for _ in range(ENCODER_COUNT)]
    valid = [0] * ENCODER_COUNT
    tac = {}
    tac_frames = {}
    start = prev_host = prev_ts = None

    with open(path, newline="") as f:
        rows = csv.reader(f)
        header = next(rows, None)
        if not header or header[:2] != ["host_time", "board_ts_ms"]:
            raise RecordingError("not a DexUMI Hand Monitor recording")
        col = {name: i for i, name in enumerate(header)}
        enc_cols = [col.get(f"enc{i}") for i in range(ENCODER_COUNT)]
        tac_ids = sorted({int(n[3:].split("_")[0]) for n in header if n.startswith("tac") and n.endswith("_n1")})
        tac_cols = {sid: [col[f"tac{sid}_{k}"] for k in TACTILE_KEYS] for sid in tac_ids}
        for sid in tac_ids:
            tac[sid] = [[] for _ in TACTILE_KEYS]
            tac_frames[sid] = 0

        for row in rows:
            if len(row) != len(header) or row[0] == "host_time":
                continue  # a header repeated by appending to an existing file
            try:
                host = float(row[0])
                ts = int(row[1])
            except ValueError:
                continue
            if start is None:
                start = host
            elif host - prev_host > OUTAGE_S and (ts < prev_ts or ts - prev_ts > OUTAGE_S * 1000):
                state.mark_offline(prev_host)
            prev_host, prev_ts = host, ts

            encoders = {}
            for i, c in enumerate(enc_cols):
                if c is not None:
                    cell = row[c]
                    encoders[i] = float(cell) if cell else float("nan")
            tactiles = {}
            for sid, cols in tac_cols.items():
                cells = [row[c] for c in cols]
                if cells[0] != "":
                    tactiles[sid] = dict(zip(TACTILE_KEYS, (int(v) for v in cells)), raw=())
            state.on_frame(0x10, 0x20, ts, encoders, tactiles, now=host)

            times.append(round(host - start, 4))
            for i in range(ENCODER_COUNT):
                value = state.frame_values[i]
                enc[i].append(value)
                if value is not None:
                    valid[i] += 1
            for sid in tac_ids:
                sample = tactiles.get(sid)
                if sample is not None:
                    tac_frames[sid] += 1
                for k, key in enumerate(TACTILE_KEYS):
                    tac[sid][k].append(sample[key] if sample is not None else None)

    frames = len(times)
    duration = times[-1] if times else 0.0
    events = [
        {
            "t": round(t - start, 4),
            "wall": time.strftime("%H:%M:%S", time.localtime(t)),
            "kind": kind,
            "enc": encoder,
            "text": text,
        }
        for _, t, kind, encoder, text in state.events
    ]
    summary = {
        "start": start,
        "start_str": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start)) if start else None,
        "duration": duration,
        "frames": frames,
        "fps": (frames - 1) / duration if duration > 0 else 0.0,
        "period_ms": state.period_ms,
        "dropped": state.dropped,
        "gaps": state.gaps,
        "longest_gap_ms": state.longest_gap_ms,
        "board_resets": state.board_resets,
        "outages": sum(1 for e in events if e["kind"] == "link" and e["text"].startswith("USB link lost")),
        "glitches": sum(state.glitches),
        "live_encoders": sum(1 for v in valid if frames and v / frames > 0.5),
        "encoders": [
            {
                "min": _round(state.vmin[i]),
                "max": _round(state.vmax[i]),
                "good": valid[i] / frames if frames else None,
                "glitches": state.glitches[i],
            }
            for i in range(ENCODER_COUNT)
        ],
        "tactile": {
            str(sid): {
                "frames": tac_frames[sid],
                "n1_max": max((v for v in tac[sid][0] if v is not None), default=0),
                "n2_max": max((v for v in tac[sid][3] if v is not None), default=0),
            }
            for sid in tac_ids
        },
    }
    data = {
        "t": times,
        "enc": enc,
        "tac": {str(sid): cols for sid, cols in tac.items() if tac_frames[sid]},
        "events": events,
    }
    return summary, data


class Library:
    """Summaries are cached per file version; full replay data for the last few files."""

    def __init__(self, directory, glitch_rate):
        self.directory = directory
        self.glitch_rate = glitch_rate
        self._lock = threading.Lock()
        self._summaries = {}  # name -> (mtime, size, summary)
        self._full = OrderedDict()  # name -> (mtime, size, data)

    def _version(self, path):
        st = os.stat(path)
        return st.st_mtime, st.st_size

    def listing(self, active=None):
        files = []
        if os.path.isdir(self.directory):
            for name in os.listdir(self.directory):
                path = os.path.join(self.directory, name)
                if not name.endswith(".csv") or not os.path.isfile(path):
                    continue
                mtime, size = self._version(path)
                cached = self._summaries.get(name)
                summary = cached[2] if cached and cached[:2] == (mtime, size) else None
                files.append({
                    "name": name,
                    "size": size,
                    "mtime": mtime,
                    "recording": name == active,
                    "summary": summary,
                })
        files.sort(key=lambda f: f["mtime"], reverse=True)
        return {"dir": self.directory, "files": files}

    def _analyze(self, name):
        path = safe_path(self.directory, name)
        version = self._version(path)
        with self._lock:
            cached = self._summaries.get(name)
            full = self._full.get(name)
            if cached and full and cached[:2] == version == full[:2]:
                self._full.move_to_end(name)
                return cached[2], full[2]
        summary, data = analyze(path, self.glitch_rate)
        with self._lock:
            self._summaries[name] = (*version, summary)
            self._full[name] = (*version, data)
            while len(self._full) > FULL_CACHE_SIZE:
                self._full.popitem(last=False)
        return summary, data

    def summary(self, name):
        path = safe_path(self.directory, name)
        cached = self._summaries.get(name)
        if cached and cached[:2] == self._version(path):
            return cached[2]
        return self._analyze(name)[0]

    def load(self, name):
        summary, data = self._analyze(name)
        return dict(data, name=name, summary=summary)

    def delete(self, name, active=None):
        if name == active:
            raise RecordingError("stop recording before deleting this file")
        os.remove(safe_path(self.directory, name))
        with self._lock:
            self._summaries.pop(name, None)
            self._full.pop(name, None)
